%%%%%%%%%%%%%%%% Example with t^3 %%%%%%%%%%%%%%

clear;
tt=0:1/128:4-1/128;del_t=1/128; % J0=ceil(0.5*L/del_loga); 
Ph1=3*(tt-2).^3+29*tt; der_Ph1=9*(tt-2).^2+29;dder_Ph1=18*(tt-2);
x1=exp(1i*2*pi*Ph1);
Ph2=-3*(tt-2).^3+47*tt; der_Ph2=-9*(tt-2).^2+47;dder_Ph2=-18*(tt-2);
x2=exp(1i*2*pi*Ph2);
signal=x1+x2; chr_range=50; 
%del_loga=1/128;
del_loga=1/64;
del_cr=1/4;

% figure
% plot(tt,der_Ph2)
% hold on
% plot(tt,der_Ph1)
% 
% figure
% plot(tt,dder_Ph2)
% hold on
% plot(tt,dder_Ph1)

%Dec 9, 2024, by Jiang, chr_range=50; del_loga=1/64;del_cr=1/4;
%l=2.5，4.2, %J0=ceil(0.5*L/del_loga);
% refined with 0.01 step,l=2.5, gs1=4.21

gs1=4.21; 
mu=1;
thre=0.0001;

 tic, 
% [Ome1, Lam1, tW, TSCr1, denom, aa_dis,chr_dis, del_loga,chr_range]=TSCr_phasefunct_3rd(signal,del_t,del_loga,del_cr,chr_range,gs1,thre); 
 [Ome1, Lam1, tW, TSCr1, denom, aa_dis,chr_dis, del_loga,chr_range]=TSCr_phasefunct_3rd_con(signal,del_t,del_loga,del_cr,chr_range,gs1,thre); 
disp("running TSCr_phasefunct_3rd")
 toc


%% filter-matched CT
tic,
   Tf_fm1=filter_CT_window_rev1(TSCr1,aa_dis,chr_dis,tt,del_loga);
toc

tic,
   Tf_fm2=XR_TSCr(TSCr1,aa_dis,chr_dis,tt,del_loga);
toc

%% (Multiple) squeezing  
%%%%%%% [Tf_sc, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(iter_num, TSCr,Ome, Lam2, denom,del_t,del_loga,chr_range,freq_resol,chr_resol,gam);
%  [MTSCR0, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(5, TSCr1,Ome1, Lam1, denom,del_t,del_loga,chr_range,1/8,del_cr,thre);
[MTSCR, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(1, Tf_fm1,Ome1, Lam1, denom,del_t,del_loga,chr_range,1/8,del_cr,thre);

%% 3D ridge extraction
[IFs,CRs]=Ridge3D_max(MTSCR,2,15,15,15);
%[IFs,CRs]=Ridge3D_max(MTSCR0,2,15,15,15);

 % if1 = smooth(medfilt1(newfreq_dis(IFs(:,1)))); if2 = smooth(medfilt1(newfreq_dis(IFs(:,2))));
 % chirp1=smooth(medfilt1(newchr_dis(CRs(:,1)))); chirp2=smooth(medfilt1(newchr_dis(CRs(:,2))));
 if1 = (newfreq_dis(IFs(:,1)));
 if2 = (newfreq_dis(IFs(:,2)));
 chirp1=(newchr_dis(CRs(:,1)));
 chirp2=(newchr_dis(CRs(:,2)));

% Plot of the extracted instantaneous frequencies
figure
plot(tt,if1)
hold on
plot(tt,der_Ph1)
hold on

plot(tt,if2)
hold on
plot(tt,der_Ph2)
axis xy; 
xlabel('time (s)'); 
ylabel('frequency (Hz)'); 
title('3D ridge of IFs'); 

figure
plot(tt,chirp1)
hold on
plot(tt,dder_Ph1)
hold on
plot(tt,chirp2)
hold on
plot(tt,dder_Ph2)
axis xy; 
xlabel('time (s)'); 
ylabel('chirprate (Hz)'); 
title(' 3D ridge of CRs'); 

[MSEIf1,MSEIf2,MSECr1,MSECr2] = MSE_ridge(CRs,IFs,der_Ph1,dder_Ph1,der_Ph2,dder_Ph2,newfreq_dis,newchr_dis);
display(MSEIf1); display(MSECr1);
display(MSEIf2); display(MSECr2);


figure, mesh(squeeze(abs(TSCr1(112,:,:)))); %for del_loga=1/64; if del_loga=1/128, use abs(TSCR1(224,:,:))
figure, mesh(squeeze(abs(Tf_fm1(112,:,:)))); %for del_loga=1/64


%% intersection of signal,   TSCR1,Tf_fm decay of chirprate
slice2 =squeeze(abs(TSCr1(224/2,129,:)));
figure
plot(chr_dis,slice2);
axis xy; 

slice3 =squeeze(abs(Tf_fm1(224/2,129,:)));
figure
% plot(chr_dis,slice3./max(slice3));
 plot(chr_dis,slice3);
axis xy; 

slice4 =squeeze(abs(Tf_fm2(224/2,129,:)));
figure
% plot(chr_dis,slice3./max(slice3));
 plot(chr_dis,slice4);
axis xy; 

%% intersection of signal,   MTSCR  decay of chirprate
slice1 =squeeze(abs(MTSCR(304,129,:)));
figure
plot(newchr_dis,slice1);
axis xy; 