% function 
%               recov=TSCr_SSO_recov_group(tt,aa_dis,chr_dis,IFs,CRs,chirp1,chirp2,if1,if2,gs,TSCR);
%  component recover: works for two components only
%  output: 
% recov: a matrix of two rows with first row is x1 or x2, the other row the
% other component 


%%%% function [recov,errorx1,errorx2]=recov_sso(tt,x1,x2,aa_dis,chr_dis,IFs,CRs,chirp1,chirp2,if1,if2,gs,TSCR)

function recov=TSCr_SSO_recov_group(tt,aa_dis,chr_dis,IFs,CRs,chirp1,chirp2,if1,if2,gs,TSCR)


t_dix=1:length(tt);
recov = zeros(2,length(tt));
NIFs=zeros(size(IFs));NCRs=zeros(size(CRs));

for j=1:length(tt)
    diff1=abs(1./aa_dis-if1(j)); diff2=abs(1./aa_dis-if2(j));
       
    [minValue1, minIndex1] = min(diff1); [minValue2, minIndex2] = min(diff2);
    NIFs(j,1)=minIndex1; NIFs(j,2)=minIndex2;


    diff3=abs(chr_dis-chirp1(j)); diff4=abs(chr_dis-chirp2(j));     
    [minValue3, minIndex3] = min(diff3); [minValue4, minIndex4] = min(diff4);
    NCRs(j,1)=minIndex3; NCRs(j,2)=minIndex4;

end

for char = 1:length(tt)
    tmp = zeros(2,2);
    tmp(1,1) = 1;
    tmp(1,2) = Gaussian_tg(1-1*if2(char)/if1(char),(chirp1(char)-chirp2(char))*(1/if1(char))^2, gs)    ;
    tmp(2,1) = Gaussian_tg(1-1*if1(char)/if2(char),(chirp2(char)-chirp1(char))*(1/if2(char))^2, gs) ;
    tmp(2,2) = 1 ;  
    xtmp = [TSCR(NIFs(char,1),char,NCRs(char,1)); TSCR(NIFs(char,2),char,NCRs(char,2))];
    recov(:,char) = pinv(tmp + 1*eps) * xtmp;   
end

% if sum(abs(x1-recov(1,:)))<sum(abs(x2-recov(1,:)))
%   figure
%   plot(tt, real(x1(t_dix))-real(recov(1,t_dix)), 'color', 'k');
%   ylim([-1.5 1.5])
%   xlabel('time (s)');
%   title('Sig 1')
% 
%   figure
%   plot(tt, real(x2(t_dix))-real(recov(2,t_dix)), 'color', 'k');
%   ylim([-1.5 1.5])
%   xlabel('time (s)');
%   title('Sig 2')
% 
% 
% 
% 
% 
% else
%   figure
%   plot(tt, real(x1(t_dix))-real(recov(2,t_dix)), 'color', 'k');
%   ylim([-1.5 1.5])
%   xlabel('time (s)');
%   title('Sig 1')
% 
%   figure
%   plot(tt, real(x2(t_dix))-real(recov(1,t_dix)), 'color', 'k');
%   ylim([-1.5 1.5])
%   xlabel('time (s)');
%   title('Sig 2')
% end

%  [errorx1,errorx2] = MSE_recov_error(x1,x2,recov);
%  display (errorx1)
%  display (errorx2)




   function [CTg] = Gaussian_tg(et, ch, gs)   
    L0 = 1 + 1i * 2 * pi * ch .* (gs.^2); 
    CTg = 1 ./ sqrt(L0) .* exp(-2 * pi^2 * gs.^2 * (et.^2) ./ L0);
   
    end

end