% Oct, 2024
%%  Note you need choose c0 below for J0=ceil(c0*L/del_loga).
% c0 is a number between 0.3 and 1. Here we set c0=0.5 for computation efficience. 
% You need to set c0=1 in some cases. Please use "figure, mesh(abs(tW))" to display CWT to decide c0     
%
%         function [Omg, Lam, tW, TSCr, a_discrete,chr_dis,del_loga,chr_range]=TSCr_phasefunct_3rd(f,del_t,del_loga,del_cr,chr_range,sigma, gam); 
% 3rd： 3rd order for IF, chirp rate 
%
% f, input signal, with length 2^{L+1} (if not, make f have a length of 2^{L+1} by zero padding
% del_t,  time sample rate (if the user does not know del_t, then set del_t=1) 
% del_loga, =1/64 or 1/128
% del_cr, chirprate sample rate for TSCr
% chr_range, chrirp rate in the range of [-chr_range, chr_range]
% sigma, sigma in the Gaussian window 
% gam  threshold (10^(-4) for noiseless case)
%
%
% 
% outputs
% Omg: Omega --- IF estimation  
% TSCr: (denoted by C0 below) time-scale-chirprate transform, ceil(L/del_a) by 2^{L+1} by (1+20/del_cr) matrix, T_f(a_j,t_m, ch_n); 
% 
% tW:  CWT, ceil(L/del_a) by 2^{L+1} matrix, W_f(a_j,t_m)

function [Ome, Lam, tW, C0, denom, a_discrete0, chr, del_loga, chr_range]=TSCr_phasefunct_3rd(f,del_t,del_loga,del_cr,chr_range,gs1,gam);
%We consider the chirprate in [-chr_range, chr_range];  

chr=-chr_range:del_cr:chr_range;

mu=1; 

%del_loga=1/128; % you may set del_a=1/128, 1/64, ...

del_a=2^(del_loga); 

[M,N]=size(f); 

if M>N %make f is a row vector
    f=f'; 
    N=M; 
end

L=ceil(log(N)/log(2))-1; 
 
%f=[f, zeros(1,2^(L+1)-N)]; 

%f=my_hilbert(real(f)); 

N0=N;
%N=2^(L+1); 

%J_1=ceil(log(mu)/log(2)/del_loga); J0=ceil((L+log(mu)/log(2))/del_loga); 
%J_1=ceil(log(1/gs)/log(2)/del_loga);
%J0=ceil((L+log(1/gs)/log(2))/del_loga);
         
  % J0=ceil(L/del_loga);                            
c0=0.5; J0=ceil((c0*L)/del_loga);

%a_discrete=del_a.^((J_1:J0)); %note that a_discrete is not multiplied here by del_t. So drop del_t in other places
%a_discrete=del_a.^((1:J0));
a_discrete=del_a.^((1:J0));
a_discrete0=a_discrete*del_t; 
 fftf=fft(f); 
%tW0=zeros(J0-J_1+1, N);
tW0=zeros(J0, N);tW=zeros(J0, N0);

for j=1:J0
        %before May 2016, hat_Psi_j=wavelet_FT_Morlet(a_discrete(j)*[0:1/N:1-1/N]);
       hat_Psi_j=wavelet_FT_Morlet_sigmma(a_discrete(j)*([0:1/N:1/2]),gs1);    
       tW0(j,:)=ifft([fftf(1:N/2+1).*hat_Psi_j,zeros(1,N/2-1)]); 
   end 
tW(:,1:N0)=tW0(:,1:N0);

N3=length(chr);

C0=zeros(J0,N0,N3); C1=zeros(J0,N0,N3);  C2=zeros(J0,N0,N3); 
C3=zeros(J0,N0,N3); C4=zeros(J0,N0,N3); 

freq0=[0:1/N:1/2,-1/N:-1/N:-1/2+1/N];

for j=1:J0 
    for n=1:N3
[CTgjn, CT_tgjn, CT_ttgjn, CT_tttgjn, CT_ttttgjn]=Gaussian_ttttg_CT(mu-a_discrete(j)*freq0,chr(n)*a_discrete0(j)^2,gs1);
%       TSCr(j,:,n)=ifft(fftf.*CTgjn);
%       TSCr_t(j,:,n)=ifft(fftf.*CT_tgjn);
%       TSCr_tt(j,:,n)=ifft(fftf.*CT_ttgjn);
%       TSCr_ttt(j,:,n)=ifft(fftf.*CT_tttgjn);
%       TSCr_tttt(j,:,n)=ifft(fftf.*CT_ttttgjn);
      C0(j,:,n)=ifft(fftf.*CTgjn);
      C1(j,:,n)=ifft(fftf.*CT_tgjn);
      C2(j,:,n)=ifft(fftf.*CT_ttgjn);
      C3(j,:,n)=ifft(fftf.*CT_tttgjn);
      C4(j,:,n)=ifft(fftf.*CT_ttttgjn);

   end 
end 

size(C0)

 
denom=C0.*(C2.*C4-C3.^2)-C1.^2.*C4+2*C1.*C2.*C3-C2.^3; 
D1=2*C1.*(C1.*C3-C2.^2)-C0.*(C1.*C4-C2.*C3); 
ings=1/gs1^2; 
D2=ings*C1.*(C1.*C4-C2.*C3)+(C0-ings*C2).*(C0.*C4-C2.^2)-(2*C1-ings*C3).*(C0.*C3-C1.*C2); 

clear C1 C2 C3 C4
Ome=zeros(J0,N,N3);  Lam=zeros(J0,N,N3); 

A0=zeros(J0,N,N3); A0sq=zeros(J0,N,N3); %lam0=zeros(J0,N,N3); 
 one0=ones(N,N3); one1=ones(J0,N); 

 for j=1:J0
     A0(j,:,:)=1/a_discrete0(j)*one0; A0sq(j,:,:)=1/(a_discrete0(j)^2)*one0;
 end 

 for n=1:N3
     lam0(:,:,n)=chr(n)*one1; 
 end 

 in2p=1/2/pi/i; 
denom= denom+1e-10;
Ome=A0-A0.*real(in2p*(D1)./denom); 
Lam=lam0-A0sq.*real(in2p*(D2)./denom); 

clear D1 D2 A0 A0sq lam0; 

freq_bound=1/2/del_t; 
ind0=(abs(C0)<gam); 
ind1=(abs(denom)<gam);
ind2=(Ome>freq_bound)|(Ome <= gam); 
mch=max(abs(chr)); ind3=(abs(Lam)>mch); 

Ome(ind0)=0; Ome(ind1)=0;Ome(ind2)=0;
Lam(ind0)=0; Lam(ind1)=0;Lam(ind3)=0;

clear ind1 ind2 ind3 ind0
