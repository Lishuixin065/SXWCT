% May 27, 2024
%
%         function CTg=Gaussian_CT(et,ch,gs); 
%
% chirplet transform of Gaussian func g(t)= exp(-t^2/(2*gs^2)/gs/sqrt(2*pi);
% CTg=int g(tau) exp(-i2pi et tau -i pi ch tau^2) dtau 
% 
% et: eta, freq
% ch: lambda, chirprate 
% gs: sigma, the parameter of Gaussian window function 

function CTg=Gaussian_CT(et,ch,gs);

L0=1+i*2*pi*ch*gs^2;

CTg=1./sqrt(L0).*exp(-2*pi^2*gs^2*et.^2./L0);

%CTg=(1./L0).*exp(-2*2*pi^2*gs^2*et.^2./L0);