% Sep 12, 2024
% function  
%           [Tf_sc, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(iter_num, TSCr,Ome, Lam2, denom, del_t,del_loga,chr_range,freq_resol,chr_resol,gam);
% Stscr: multple squeezing TSCr
% freq:  TSCr was calculated via freq domain (fft is used)
% MOmeLam: multiple Omega, Lamba are calculated 
% iter_num: iteration number for squeezing, you can choose it to be 1, 2,
% up to 7. 
% del_t,  time sample rate (if the user does not know del_t, then set del_t=1) 
% del_loga,1/64, 1/128, the step for a
% chr_range, [-chr_range, chr_range] is the range for chirp rate 
% freq_resol, fre resolution for Stscr
% chr_resol, chirp-rate resolution for Stscr   
% gam  threshold (10^(-4) or 10^(-5). 10^(-8) for noiseless case)

function   [Tf_sc, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(iter_num, TSCr,Ome, Lam2, denom,del_t,del_loga,chr_range,freq_resol,chr_resol,gam);

nu0=del_loga; % this nu0 is 1/nu, where nu is the one in Daub-Lu_Wu's paper 

% aa_dis=a_discrete0; 
[N1,N2,N3]=size(Ome); 

MM=ceil(1/(2*del_t*freq_resol)); 
del_w=freq_resol; newfreq_dis=(1:MM)*del_w; 

del_la=chr_resol; del_cr=chr_resol;

MMc=ceil(2*chr_range/del_la); 
newchr_dis=[-chr_range:del_la:chr_range]; %size(chr_dis)

chr_start=floor(chr_range/del_la); %you can modifiy chr_range in TSCr_phasefunct

TSCr_abs=abs(TSCr); denom_abs=abs(denom);

disp("obtaining valid_indicies:")
tic
valid_indices = (TSCr_abs > gam) & (Ome > gam)&(denom_abs > gam);
toc;

clear TSCr_abs denom denom_abs 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% iter_num==10 %%%%%%%%%%%%%%%%%
if (iter_num==10)

 PP=round(Ome/del_w); QQ=round(Lam2/del_la)+chr_start+1; 

clear Ome Lam2 

Tf_sc=zeros(MM,N2,MMc+1); 
disp("iter 10, 1st squeezing freq, Tf_sc_freq")
tic 
for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p=PP(j,m,k);   %q=QQ(j,m,k);
                   if (p>0)&(p<=MM)
Tf_sc(MM-p+1,m,k)=Tf_sc(MM-p+1,m,k)+TSCr(j,m,k); 
                   end
                 end
            end
        end 
end
Tf_sc=log(2)*del_loga*Tf_sc;
toc

end %%%%%%%%%%%%%%%%%%% end of iter_num=10




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% iter_num==1 %%%%%%%%%%%%%%%%%
if (iter_num==1)

 PP=round(Ome/del_w); QQ=round(Lam2/del_la)+chr_start+1; 

clear Ome Lam2 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%  Tf_sc %%%%%%%%%%
disp("1st squeezing, Tf_sc")
Tf_sc=zeros(MM,N2,MMc+1); 
tic 
for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p=PP(j,m,k);   q=QQ(j,m,k);
                   if (p>0)&(p<=MM)&(q>0)&(q<=MMc+1)
Tf_sc(p,m,q)=Tf_sc(p,m,q)+TSCr(j,m,k); 
                   end
                 end
            end
        end 
end
Tf_sc=log(2)*del_loga*del_cr*Tf_sc;
toc

end %%%%%%%%%%%%%%%%%%% end of iter_num=1


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% iter_num==2 %%%%%%%%%%%%%%%%%
if (iter_num==2)

PP2=round(-log(Ome*del_t)/(log(2)*nu0)); QQ2=round(Lam2/del_la)+chr_start+1; 

disp("calculating Omega2, Lambda2:")

tic
Ome_it2=zeros(N1,N2,N3);Lam_it2=zeros(N1,N2,N3);
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p2=PP2(j,m,k);   q2=QQ2(j,m,k);
                   if (p2>0)&(p2<=N1)&(q2>0)&(q2<=N3)
Ome_it2(j,m,k)=Ome(p2,m,q2); Lam_it2(j,m,k)=Lam2(p2,m,q2); 
                   end
                 end
            end
        end 
 end
 toc 

 tic 
disp("2nd squeezing, Tf_sc")

PP=round(Ome_it2/del_w); QQ=round(Lam_it2/del_la)+chr_start+1;

clear PP2 QQ2 Ome Lam2 Ome_it2 Lam_it2

Tf_sc=zeros(MM,N2,MMc+1); 

for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p=PP(j,m,k);   q=QQ(j,m,k);
                   if (p>0)&(p<=MM)&(q>0)&(q<=MMc+1)
Tf_sc(p,m,q)=Tf_sc(p,m,q)+TSCr(j,m,k); 
                   end
                 end
            end
        end 
end
Tf_sc=log(2)*del_loga*del_cr*Tf_sc;
toc

end %%%%%%%%%%%%%%%%%%% end of iter_num=2



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% iter_num==3 %%%%%%%%%%%%%%%%%
if (iter_num==3)


disp("calculating Omega2, Lambda2:")

PP2=round(-log(Ome*del_t)/(log(2)*nu0)); QQ2=round(Lam2/del_la)+chr_start+1; 

tic
Ome_it2=zeros(N1,N2,N3);Lam_it2=zeros(N1,N2,N3);
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p2=PP2(j,m,k);   q2=QQ2(j,m,k);
                   if (p2>0)&(p2<=N1)&(q2>0)&(q2<=N3)
Ome_it2(j,m,k)=Ome(p2,m,q2); Lam_it2(j,m,k)=Lam2(p2,m,q2); 
                   end
                 end
            end
        end 
 end
 toc 

disp("calculating Omega3, Lambda3:")

PP3=round(-log(Ome_it2*del_t)/(log(2)*nu0)); QQ3=round(Lam_it2/del_la)+chr_start+1; 
clear PP2 QQ2 Ome_it2 Lam_it2

tic
Ome_it3=zeros(N1,N2,N3);Lam_it3=zeros(N1,N2,N3);
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p3=PP3(j,m,k);   q3=QQ3(j,m,k);
                   if (p3>0)&(p3<=N1)&(q3>0)&(q3<=N3)
Ome_it3(j,m,k)=Ome(p3,m,q3); Lam_it3(j,m,k)=Lam2(p3,m,q3); 
                   end
                 end
            end
        end 
 end
 toc 

 tic 
disp("3rd squeezing, Tf_sc")

PP=round(Ome_it3/del_w); QQ=round(Lam_it3/del_la)+chr_start+1;

clear Ome Lam2 Ome_it3 Lam_it3 PP3 QQ3

Tf_sc=zeros(MM,N2,MMc+1); 

for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p=PP(j,m,k);   q=QQ(j,m,k);
                   if (p>0)&(p<=MM)&(q>0)&(q<=MMc+1)
Tf_sc(p,m,q)=Tf_sc(p,m,q)+TSCr(j,m,k); 
                   end
                 end
            end
        end 
end
Tf_sc=log(2)*del_loga*del_cr*Tf_sc;
toc

end %%%%%%%%%%%%%%%%%%% end of iter_num=3


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% iter_num==4 %%%%%%%%%%%%%%%%%
if (iter_num==4)

disp("calculating Omega2, Lambda2:")

PP2=round(-log(Ome*del_t)/(log(2)*nu0)); QQ2=round(Lam2/del_la)+chr_start+1; 

tic
Ome_it2=zeros(N1,N2,N3);Lam_it2=zeros(N1,N2,N3);
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p2=PP2(j,m,k);   q2=QQ2(j,m,k);
                   if (p2>0)&(p2<=N1)&(q2>0)&(q2<=N3)
Ome_it2(j,m,k)=Ome(p2,m,q2); Lam_it2(j,m,k)=Lam2(p2,m,q2); 
                   end
                 end
            end
        end 
 end
 toc 

disp("calculating Omega3, Lambda3:")

PP3=round(-log(Ome_it2*del_t)/(log(2)*nu0)); QQ3=round(Lam_it2/del_la)+chr_start+1; 
clear PP2 QQ2 Ome_it2 Lam_it2

tic
Ome_it3=zeros(N1,N2,N3);Lam_it3=zeros(N1,N2,N3);
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p3=PP3(j,m,k);   q3=QQ3(j,m,k);
                   if (p3>0)&(p3<=N1)&(q3>0)&(q3<=N3)
Ome_it3(j,m,k)=Ome(p3,m,q3); Lam_it3(j,m,k)=Lam2(p3,m,q3); 
                   end
                 end
            end
        end 
 end
 toc 



disp("calculating Omega4, Lambda4:")

PP4=round(-log(Ome_it3*del_t)/(log(2)*nu0)); QQ4=round(Lam_it3/del_la)+chr_start+1; 
clear PP3 QQ3 Ome_it3 Lam_it3

tic
Ome_it4=zeros(N1,N2,N3);Lam_it4=zeros(N1,N2,N3);

 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p4=PP4(j,m,k);   q4=QQ4(j,m,k);
                   if (p4>0)&(p4<=N1)&(q4>0)&(q4<=N3)
Ome_it4(j,m,k)=Ome(p4,m,q4); Lam_it4(j,m,k)=Lam2(p4,m,q4); 
                   end
                 end
            end
        end 
 end
 toc 


 tic 
disp("4th squeezing, Tf_sc")

PP=round(Ome_it4/del_w); QQ=round(Lam_it4/del_la)+chr_start+1;

clear Ome Lam2 Ome_it4 Lam_it4 PP4 QQ4

Tf_sc=zeros(MM,N2,MMc+1); 

for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p=PP(j,m,k);   q=QQ(j,m,k);
                   if (p>0)&(p<=MM)&(q>0)&(q<=MMc+1)
Tf_sc(p,m,q)=Tf_sc(p,m,q)+TSCr(j,m,k); 
                   end
                 end
            end
        end 
end
Tf_sc=log(2)*del_loga*del_cr*Tf_sc;
toc

end %%%%%%%%%%%%%%%%%%% end of iter_num=4


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% iter_num==5 %%%%%%%%%%%%%%%%%
if (iter_num==5)

disp("calculating Omega2, Lambda2:")

PP2=round(-log(Ome*del_t)/(log(2)*nu0)); QQ2=round(Lam2/del_la)+chr_start+1; 

tic
Ome_it2=zeros(N1,N2,N3);Lam_it2=zeros(N1,N2,N3);
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p2=PP2(j,m,k);   q2=QQ2(j,m,k);
                   if (p2>0)&(p2<=N1)&(q2>0)&(q2<=N3)
Ome_it2(j,m,k)=Ome(p2,m,q2); Lam_it2(j,m,k)=Lam2(p2,m,q2); 
                   end
                 end
            end
        end 
 end
 toc 

disp("calculating Omega3, Lambda3:")

PP3=round(-log(Ome_it2*del_t)/(log(2)*nu0)); QQ3=round(Lam_it2/del_la)+chr_start+1; 
clear PP2 QQ2 Ome_it2 Lam_it2

tic
Ome_it3=zeros(N1,N2,N3);Lam_it3=zeros(N1,N2,N3);
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p3=PP3(j,m,k);   q3=QQ3(j,m,k);
                   if (p3>0)&(p3<=N1)&(q3>0)&(q3<=N3)
Ome_it3(j,m,k)=Ome(p3,m,q3); Lam_it3(j,m,k)=Lam2(p3,m,q3); 
                   end
                 end
            end
        end 
 end
 toc 



disp("calculating Omega4, Lambda4:")

PP4=round(-log(Ome_it3*del_t)/(log(2)*nu0)); QQ4=round(Lam_it3/del_la)+chr_start+1; 
clear PP3 QQ3 Ome_it3 Lam_it3

tic
Ome_it4=zeros(N1,N2,N3);Lam_it4=zeros(N1,N2,N3);
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p4=PP4(j,m,k);   q4=QQ4(j,m,k);
                   if (p4>0)&(p4<=N1)&(q4>0)&(q4<=N3)
Ome_it4(j,m,k)=Ome(p4,m,q4); Lam_it4(j,m,k)=Lam2(p4,m,q4); 
                   end
                 end
            end
        end 
 end
 toc 


disp("calculating Omega5, Lambda5:")

PP5=round(-log(Ome_it4*del_t)/(log(2)*nu0)); QQ5=round(Lam_it4/del_la)+chr_start+1; 
clear PP4 QQ4 Ome_it4 Lam_it4

tic
Ome_it5=zeros(N1,N2,N3);Lam_it5=zeros(N1,N2,N3);
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p5=PP5(j,m,k);   q5=QQ5(j,m,k);
                   if (p5>0)&(p5<=N1)&(q5>0)&(q5<=N3)
Ome_it5(j,m,k)=Ome(p5,m,q5); Lam_it5(j,m,k)=Lam2(p5,m,q5); 
                   end
                 end
            end
        end 
 end
 toc 

 tic 
disp("5th squeezing, Tf_sc")

PP=round(Ome_it5/del_w); QQ=round(Lam_it5/del_la)+chr_start+1;

clear Ome Lam2 Ome_it5 Lam_it5 PP5 QQ5

Tf_sc=zeros(MM,N2,MMc+1); 

for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p=PP(j,m,k);   q=QQ(j,m,k);
                   if (p>0)&(p<=MM)&(q>0)&(q<=MMc+1)
Tf_sc(p,m,q)=Tf_sc(p,m,q)+TSCr(j,m,k); 
                   end
                 end
            end
        end 
end
Tf_sc=log(2)*del_loga*del_cr*Tf_sc;
toc

end %%%%%%%%%%%%%%%%%%% end of iter_num=5



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% iter_num==6 %%%%%%%%%%%%%%%%%
if (iter_num==6)

disp("calculating Omega2, Lambda2:")

PP2=round(-log(Ome*del_t)/(log(2)*nu0)); QQ2=round(Lam2/del_la)+chr_start+1; 

tic
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p2=PP2(j,m,k);   q2=QQ2(j,m,k);
                   if (p2>0)&(p2<=N1)&(q2>0)&(q2<=N3)
Ome_it2(j,m,k)=Ome(p2,m,q2); Lam_it2(j,m,k)=Lam2(p2,m,q2); 
                   end
                 end
            end
        end 
 end
 toc 

disp("calculating Omega3, Lambda3:")

PP3=round(-log(Ome_it2*del_t)/(log(2)*nu0)); QQ3=round(Lam_it2/del_la)+chr_start+1; 
clear PP2 QQ2 Ome_it2 Lam_it2

tic
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p3=PP3(j,m,k);   q3=QQ3(j,m,k);
                   if (p3>0)&(p3<=N1)&(q3>0)&(q3<=N3)
Ome_it3(j,m,k)=Ome(p3,m,q3); Lam_it3(j,m,k)=Lam2(p3,m,q3); 
                   end
                 end
            end
        end 
 end
 toc 



disp("calculating Omega4, Lambda4:")

PP4=round(-log(Ome_it3*del_t)/(log(2)*nu0)); QQ4=round(Lam_it3/del_la)+chr_start+1; 
clear PP3 QQ3 Ome_it3 Lam_it3

tic
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p4=PP4(j,m,k);   q4=QQ4(j,m,k);
                   if (p4>0)&(p4<=N1)&(q4>0)&(q4<=N3)
Ome_it4(j,m,k)=Ome(p4,m,q4); Lam_it4(j,m,k)=Lam2(p4,m,q4); 
                   end
                 end
            end
        end 
 end
 toc 


disp("calculating Omega5, Lambda5:")

PP5=round(-log(Ome_it4*del_t)/(log(2)*nu0)); QQ5=round(Lam_it4/del_la)+chr_start+1; 
clear PP4 QQ4 Ome_it4 Lam_it4

tic
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p5=PP5(j,m,k);   q5=QQ5(j,m,k);
                   if (p5>0)&(p5<=N1)&(q5>0)&(q5<=N3)
Ome_it5(j,m,k)=Ome(p5,m,q5); Lam_it5(j,m,k)=Lam2(p5,m,q5); 
                   end
                 end
            end
        end 
 end
 toc 


disp("calculating Omega6, Lambda6:")

PP6=round(-log(Ome_it5*del_t)/(log(2)*nu0)); QQ6=round(Lam_it5/del_la)+chr_start+1; 
clear PP5 QQ5 Ome_it5 Lam_it5

tic
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p6=PP6(j,m,k);   q6=QQ6(j,m,k);
                   if (p6>0)&(p6<=N1)&(q6>0)&(q6<=N3)
Ome_it6(j,m,k)=Ome(p6,m,q6); Lam_it6(j,m,k)=Lam2(p6,m,q6); 
                   end
                 end
            end
        end 
 end
 toc 

 tic 
disp("6th squeezing, Tf_sc")

PP=round(Ome_it6/del_w); QQ=round(Lam_it6/del_la)+chr_start+1;

clear Ome Lam2 Ome_it6 Lam_it6 PP6 QQ6

Tf_sc=zeros(MM,N2,MMc+1); 

for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p=PP(j,m,k);   q=QQ(j,m,k);
                   if (p>0)&(p<=MM)&(q>0)&(q<=MMc+1)
Tf_sc(p,m,q)=Tf_sc(p,m,q)+TSCr(j,m,k); 
                   end
                 end
            end
        end 
end
Tf_sc=log(2)*del_loga*del_cr*Tf_sc;
toc

end %%%%%%%%%%%%%%%%%%% end of iter_num=6



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% iter_num==7 %%%%%%%%%%%%%%%%%
if (iter_num==7)

disp("calculating Omega2, Lambda2:")

PP2=round(-log(Ome*del_t)/(log(2)*nu0)); QQ2=round(Lam2/del_la)+chr_start+1; 

tic
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p2=PP2(j,m,k);   q2=QQ2(j,m,k);
                   if (p2>0)&(p2<=N1)&(q2>0)&(q2<=N3)
Ome_it2(j,m,k)=Ome(p2,m,q2); Lam_it2(j,m,k)=Lam2(p2,m,q2); 
                   end
                 end
            end
        end 
 end
 toc 

disp("calculating Omega3, Lambda3:")

PP3=round(-log(Ome_it2*del_t)/(log(2)*nu0)); QQ3=round(Lam_it2/del_la)+chr_start+1; 
clear PP2 QQ2 Ome_it2 Lam_it2

tic
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p3=PP3(j,m,k);   q3=QQ3(j,m,k);
                   if (p3>0)&(p3<=N1)&(q3>0)&(q3<=N3)
Ome_it3(j,m,k)=Ome(p3,m,q3); Lam_it3(j,m,k)=Lam2(p3,m,q3); 
                   end
                 end
            end
        end 
 end
 toc 



disp("calculating Omega4, Lambda4:")

PP4=round(-log(Ome_it3*del_t)/(log(2)*nu0)); QQ4=round(Lam_it3/del_la)+chr_start+1; 
clear PP3 QQ3 Ome_it3 Lam_it3

tic
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p4=PP4(j,m,k);   q4=QQ4(j,m,k);
                   if (p4>0)&(p4<=N1)&(q4>0)&(q4<=N3)
Ome_it4(j,m,k)=Ome(p4,m,q4); Lam_it4(j,m,k)=Lam2(p4,m,q4); 
                   end
                 end
            end
        end 
 end
 toc 


disp("calculating Omega5, Lambda5:")

PP5=round(-log(Ome_it4*del_t)/(log(2)*nu0)); QQ5=round(Lam_it4/del_la)+chr_start+1; 
clear PP4 QQ4 Ome_it4 Lam_it4

tic
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p5=PP5(j,m,k);   q5=QQ5(j,m,k);
                   if (p5>0)&(p5<=N1)&(q5>0)&(q5<=N3)
Ome_it5(j,m,k)=Ome(p5,m,q5); Lam_it5(j,m,k)=Lam2(p5,m,q5); 
                   end
                 end
            end
        end 
 end
 toc 


disp("calculating Omega6, Lambda6:")

PP6=round(-log(Ome_it5*del_t)/(log(2)*nu0)); QQ6=round(Lam_it5/del_la)+chr_start+1; 
clear PP5 QQ5 Ome_it5 Lam_it5

tic
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p6=PP6(j,m,k);   q6=QQ6(j,m,k);
                   if (p6>0)&(p6<=N1)&(q6>0)&(q6<=N3)
Ome_it6(j,m,k)=Ome(p6,m,q6); Lam_it6(j,m,k)=Lam2(p6,m,q6); 
                   end
                 end
            end
        end 
 end
 toc 

disp("calculating Omega7, Lambda7:")

PP7=round(-log(Ome_it6*del_t)/(log(2)*nu0)); QQ7=round(Lam_it6/del_la)+chr_start+1; 
clear PP6 QQ6 Ome_it6 Lam_it6

tic
 for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p7=PP7(j,m,k);   q7=QQ7(j,m,k);
                   if (p7>0)&(p7<=N1)&(q7>0)&(q7<=N3)
Ome_it7(j,m,k)=Ome(p7,m,q7); Lam_it7(j,m,k)=Lam2(p7,m,q7); 
                   end
                 end
            end
        end 
 end
 toc 


 tic 
disp("7th squeezing, Tf_sc")

PP=round(Ome_it7/del_w); QQ=round(Lam_it7/del_la)+chr_start+1;

clear Ome Lam2 Ome_it7 Lam_it7 PP7 QQ7

Tf_sc=zeros(MM,N2,MMc+1); 

for m=1:N2
        for j=1:N1
            for k=1:N3
                 if valid_indices(j, m, k)
                 p=PP(j,m,k);   q=QQ(j,m,k);
                   if (p>0)&(p<=MM)&(q>0)&(q<=MMc+1)
Tf_sc(p,m,q)=Tf_sc(p,m,q)+TSCr(j,m,k); 
                   end
                 end
            end
        end 
end
Tf_sc=log(2)*del_loga*del_cr*Tf_sc;
toc

end %%%%%%%%%%%%%%%%%%% end of iter_num=7




