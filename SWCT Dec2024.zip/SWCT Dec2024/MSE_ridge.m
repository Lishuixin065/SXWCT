
function [MSEIf1,MSEIf2,MSECr1,MSECr2] = MSE_ridge(CRs,IFs,der_Ph1,dder_Ph1,der_Ph2,dder_Ph2,freq_dis,chr_dis)
% MSE_ridge Calculates the mean square error of instantaneous frequency and chirp rate.
% Input parameters:
% CRs : Estimated chirp rates for the first signal set
% IFs : Estimated instantaneous frequencies for both signal sets
% der_Ph1 : True instantaneous frequency of signal x1
% dder_Ph1 : True chirp rate of signal x1
% der_Ph2 : True instantaneous frequency of signal x2
% dder_Ph2 : True chirp rate of signal x2
% freq_dis : Frequency axis
% chr_dis : Chirp rate axis
% Output parameters:
% MSEIf1 : Mean square error of the instantaneous frequency for signal x1
% MSEIf2 : Mean square error of the instantaneous frequency for signal x2
% MSECr1 : Mean square error of the chirp rate for signal x1
% MSECr2 : Mean square error of the chirp rate for signal x2



CRs=CRs';IFs=IFs';
tn=length(der_Ph1);

time=ceil(tn/8):floor(tn*7/8);
tlen=length(time);
If1=IFs(1,time);If1=freq_dis(If1);
Cr1=CRs(1,time);Cr1=chr_dis(Cr1);
If2=IFs(2,time);If2=freq_dis(If2);
Cr2=CRs(2,time);Cr2=chr_dis(Cr2);



RIf1=der_Ph1(time);RCr1=dder_Ph1(time);
RIf2=der_Ph2(time);RCr2=dder_Ph2(time);

if sum(abs(If1-RIf1))<sum(abs(If2-RIf1))
MSEIf1=sqrt(1/(tlen-1)*sum((abs(If1-RIf1)).^2));
MSEIf2=sqrt(1/(tlen-1)*sum((abs(If2-RIf2)).^2));
else
MSEIf1=sqrt(1/(tlen-1)*sum((abs(If2-RIf1)).^2));
MSEIf2=sqrt(1/(tlen-1)*sum((abs(If1-RIf2)).^2)); 
end

if sum(abs(Cr1-RCr1))<sum(abs(Cr2-RCr1))
MSECr1=sqrt(1/(tlen-1)*sum((abs(Cr1-RCr1)).^2));
MSECr2=sqrt(1/(tlen-1)*sum((abs(Cr2-RCr2)).^2));
else
MSECr1=sqrt(1/(tlen-1)*sum((abs(Cr2-RCr1)).^2));
MSECr2=sqrt(1/(tlen-1)*sum((abs(Cr1-RCr2)).^2)); 
end