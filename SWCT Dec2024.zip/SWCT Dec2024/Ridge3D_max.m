function [IF, CR] = Ridge3D_max(Tx, n, fa, ca, gd)
% Input
%   Tx : 3D space, for example, Tx(chirp-rate, frequency, time)
%    n : Number of ridges to extract
%   fa : Maximum allowable frequency variation for ridge tracing
%   ca : Maximum allowable chirp-rate variation for ridge tracing
%   gd : Adjustable parameter for mode reconstruction

% OUTPUTS:  
%   CR: Matrix of instantaneous frequencies extracted along the ridges
%   IF : Matrix of instantaneous chirprates extracted along the ridges

Et = (abs(Tx) + eps).^2; % Lower the energy size
[Ns, N, Nc] = size(Tx);
IF = zeros(n, N); % Instantaneous frequency
CR = zeros(n, N); % Instantaneous chirp-rate

e = 10e-8; % Threshold

% The algorithm
for r = 1:n
    M = max(max(max(Et)));
    s = find(Et == M, 1, 'last');
    [idf, idt, idc] = ind2sub([Ns, N, Nc], s); % idf=freq, idc=chirp, idt=time
    IF(r, idt) = idf;
    CR(r, idt) = idc;

    % Forward search
    for b = idt + 1:N
        a = max(1, idf - fa): min(Ns, idf + fa);
        c = max(1, idc - ca): min(Nc, idc + ca);

        E1 = squeeze(Et(a, b, c));

      
 [M, I] = max(E1, [], [1 2], 'linear');
        if M > e
            [idfs, idcs] = ind2sub([length(a), length(c)], I);
            idf = a(idfs);
            idc = c(idcs);
            if idf > Ns
             idf = Ns;
            end
            if idc > Nc
             idc = Nc;
            end

            IF(r, b) = idf;
            CR(r, b) = idc;

        else
            IF(r, b) = IF(r, b - 1);
            CR(r, b) = CR(r, b - 1);
        end
    end

    % Backward search
    idf = IF(r, idt);
    idc = CR(r, idt);

    for b = idt - 1:-1:1
        a = max(1, idf - fa): min(Ns, idf + fa);
        c = max(1, idc - ca): min(Nc, idc + ca);

        E2 = squeeze(Et(a, b, c));

        
 [M, I] = max(E2, [], [1 2], 'linear');
        if M > e
            [idfs, idcs] = ind2sub([length(a), length(c)], I);
            idf = a(idfs);
            idc = c(idcs);
            IF(r, b) = idf;
            CR(r, b) = idc;
             if idf > Ns
             idf = Ns;
            end

            if idc > Nc
             idc = Nc;
            end





        else
            IF(r, b) = IF(r, b + 1);
            CR(r, b) = CR(r, b + 1);
        end
    end

% Reconstruct the mode & Remove the curve
for b = 1:N
   

        c_index_low = max(CR(r,b)-gd,1);
        c_index_up = min(CR(r,b)+gd,Nc);
        f_index_low = max(IF(r,b)-gd,1);
        f_index_up = min(IF(r,b)+gd,Ns);
        Et( f_index_low:f_index_up,b,c_index_low:c_index_up)=0;
end
   
end

IF = IF';
CR = CR';

end
