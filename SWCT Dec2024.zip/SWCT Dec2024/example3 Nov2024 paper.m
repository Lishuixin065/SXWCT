%%%%%%%%%%%%%%%% Example 3 with IFs sin\cos %%%%%%%%%%%%%%

clear;
tt=0:1/128:4-1/128; del_t=1/128; %J0=ceil(0.5*L/del_loga); 
x1=exp(1i*82*pi*tt+1i*64*cos(pi*tt./2+pi/2)); 
der_Ph1=41-16*cos(pi*tt./2);
dder_Ph1=8*pi*sin(pi*tt./2);
x2=exp(1i*82*pi*tt+1i*64*cos(pi*tt./2-pi/2));
der_Ph2=41+16*cos(pi*tt./2);
dder_Ph2=-8*pi*sin(pi*tt./2);
signal=x1+x2; 
chr_range=80; del_cr=0.4;
%del_loga=1/128;
del_loga=1/64;

figure
pdph1=plot(tt,der_Ph1,'r-','linewidth',2);
hold on
pdph2=plot(tt,der_Ph2,'b-','linewidth',2);
legend([pdph1,pdph2],'\phi_1^{\prime}(t)','\phi_2^{\prime}(t)');
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
axis xy; 
axis([tt(1) 4 20 70]);
% print 'example3_Nov2024_paper_IFs_two_cosine' '-dpng' 

figure
pddph1=plot(tt,dder_Ph1,'r-','linewidth',2);
hold on
pddph2=plot(tt,dder_Ph2,'b-','linewidth',2);
legend([pddph1,pddph2],'\phi_1^{\prime\prime}(t)','\phi_2^{\prime\prime}(t)');
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
axis xy; 
axis([tt(1) 4 -26 40]);
% print 'example3_Nov2024_paper_chirprates_two_cosine' '-dpng' 



%Jiang, Dec 9, 2024
%with chr_range=80; del_cr=0.4; del_loga=1/64;
%l=2.5，gs1=5, %J0=ceil(0.5*L/del_loga);
%refined with 0.01 step,l=2.5, gs1=5.02

gs1=5.02; 
mu=1;thre=0.0001;

 tic, 
% [Ome1, Lam1, tW, TSCr1, denom, aa_dis,chr_dis, del_loga,chr_range]=TSCr_phasefunct_3rd(signal,del_t,del_loga,del_cr,chr_range,gs1,thre); 
 [Ome1, Lam1, tW, TSCr1, denom, aa_dis,chr_dis, del_loga,chr_range]=TSCr_phasefunct_3rd_con(signal,del_t,del_loga,del_cr,chr_range,gs1,thre); 
disp("running TSCr_phasefunct_3rd")
 toc

% filter-matched WCT
 tic, Tf_fm1=filter_CT_window_rev1(TSCr1,aa_dis,chr_dis,tt,del_loga);
 toc

 %colormap(hsv);
figure, mesh(chr_dis,tt,squeeze(abs(TSCr1(105,:,:)))); %for del_loga=1/64; if del_loga=1/128, use abs(TSCR1(294,:,:))
ylabel('Time (s)', 'Rotation', -21,'FontSize',20)
xlabel('Chirprate (Hz/s)', 'Rotation', 18,'FontSize',20)
set(gca,'FontSize',20)
% print 'example3_Nov2024_paper_TSCr_a105_two_cosine' '-dpng' 

figure, mesh(chr_dis,tt,squeeze(abs(Tf_fm1(105,:,:)))); %for del_loga=1/64; if del_loga=1/128, use abs(TSCR1(294,:,:))
ylabel('Time (s)', 'Rotation', -21,'FontSize',20)
xlabel('Chirprate (Hz/s)', 'Rotation', 18,'FontSize',20)
%zlabel('force[N]')
set(gca,'FontSize',20)
% print 'example3_Nov2024_paper_faird_TSCr_a105_two_cosine' '-dpng' 

 %% projection of TSCR1 onto the  plane
slice2 =squeeze(abs(TSCr1(105,129,:)));%for del_loga=1/64; if del_loga=1/128, use abs(TSCR1(294,513,:))
figure
plot(chr_dis,slice2,'linewidth',2)
xlabel('Chirprate (Hz/s)', 'FontSize',20);
axis xy; 
set(gca,'FontSize',20)
% print 'example3_Nov2024_paper_TSCr_a105_t129_two_cosine' '-dpng' 


slice3 =squeeze(abs(Tf_fm1(105,129,:)));%for del_loga=1/64; if del_loga=1/128, use abs(TSCR1(294,513,:))
figure
plot(chr_dis,slice3,'linewidth',2)
xlabel('Chirprate (Hz/s)', 'FontSize',20);
axis xy; 
set(gca,'FontSize',20)
% print 'example3_Nov2024_paper_faird_TSCr_a105_t129_two_cosine' '-dpng' 

% 3D_view 
view_3D(tt,TSCr1, aa_dis, chr_dis)
view(-135,53);
xlabel('Frequency (Hz)', 'Rotation', -34,'FontSize',20);
ylabel('Time (s)', 'Rotation', 38,'FontSize',20);
% print 'example3_Nov2024_paper_TSCr_view1_two_cosine' '-dpng' 

view_3D(tt,TSCr1, aa_dis, chr_dis)
view(156,48);
xlabel('Frequency (Hz)', 'Rotation', 15,'FontSize',20);
ylabel('Time (s)', 'Rotation', -58,'FontSize',20);
% print 'example3_Nov2024_paper_TSCr_view2_two_cosine' '-dpng' 

view_3D(tt,Tf_fm1, aa_dis, chr_dis)
zlim([-100 100])
view(-135,53);
xlabel('Frequency (Hz)', 'Rotation', -34,'FontSize',20);
ylabel('Time (s)', 'Rotation', 38,'FontSize',20);
% print 'example3_Nov2024_paper_faird_TSCr_view1_two_cosine' '-dpng' 

view_3D(tt,Tf_fm1, aa_dis, chr_dis)
zlim([-100 100])
%view(6,30);
view(156,48);
xlabel('Frequency (Hz)', 'Rotation', 15,'FontSize',20);
ylabel('Time (s)', 'Rotation', -58,'FontSize',20);
% print 'example3_Nov2024_paper_faird_TSCr_view2_two_cosine' '-dpng' 



%%%%%%%%%%% squeezing with Tf_fm1, fair decaying chirprate TSCr%%%%%%%%%%%%%%%%%%%%%%

tic, 
% [Ome1, Lam1, tW, TSCr1, denom, aa_dis,chr_dis, del_loga,chr_range]=TSCr_phasefunct_3rd(signal,del_t,del_loga,del_cr,chr_range,gs1,thre); 
 [Ome1, Lam1, tW, TSCr1, denom, aa_dis,chr_dis, del_loga,chr_range]=TSCr_phasefunct_3rd_con(signal,del_t,del_loga,del_cr,chr_range,gs1,thre); 
disp("running TSCr_phasefunct_3rd")
 toc

%%%%%%% [Tf_sc, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(iter_num, TSCr,Ome, Lam2, denom,del_t,del_loga,chr_range,freq_resol,chr_resol,gam);
[MTSCR, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(1, Tf_fm1,Ome1, Lam1, denom,del_t,del_loga,chr_range,1/8,del_cr,thre);

%% 3D ridge extraction
 [IFs,CRs]=Ridge3D_max(MTSCR,2,15,15,15);

 if1 = (newfreq_dis(IFs(:,1))); %actually this is estimated IF of x2
 if2 = (newfreq_dis(IFs(:,2)));
 chirp1=(newchr_dis(CRs(:,1))); %actually this is estimated chrirprate of x2
 chirp2=(newchr_dis(CRs(:,2)));
 % if1 = smooth(medfilt1(newfreq_dis(IFs(:,1)))); if2 = smooth(medfilt1(newfreq_dis(IFs(:,2))));
 % chirp1=smooth(medfilt1(newchr_dis(CRs(:,1)))); chirp2=smooth(medfilt1(newchr_dis(CRs(:,2))));

% Plot of the extracted instantaneous frequencies
figure
e_pdph2=plot(tt,if2,'r:','linewidth',2);
hold on
pdph2=plot(tt,der_Ph2,'b-','linewidth',1);
legend([e_pdph2,pdph2],'Estimated IF of x_2(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
%set(gca, 'YTick',[10 26 42], 'YTickLabel', {'10','26', '42'})
% axis xy; 
% axis([tt(1) 4 10 65]);
% print 'example3_Nov2024_paper_sfTSCr_estimated_IF2_two_cosine' '-dpng' 

figure
e_pdph1=plot(tt,if1,'r:','linewidth',2);
hold on
pdph1=plot(tt,der_Ph1,'b-','linewidth',1);
legend([e_pdph1,pdph1],'Estimated IF of x_1(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
% axis xy; 
% axis([tt(1) 4 20 75]);
% print 'example3_Nov2024_paper_sfTSCr_estimated_IF1_two_cosine' '-dpng' 


figure
e_pddph1=plot(tt,chirp1,'r:','linewidth',2);
hold on
pddph1=plot(tt,dder_Ph1,'b-','linewidth',1);
legend([e_pddph1,pddph1],'Estimated chirprate of x_1(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Chirprate (Hz/s)','FontSize',20);
set(gca,'FontSize',20)
axis xy; 
axis([tt(1) 4 -30 50]);
% print 'example3_Nov2024_paper_sfTSCr_estimated_chirprate1_two_cosine' '-dpng' 

figure
e_pddph2=plot(tt,chirp2,'r:','linewidth',2);
hold on
pddph2=plot(tt,dder_Ph2,'b-','linewidth',1);
legend([e_pddph2,pddph2],'Estimated chirprate of x_2(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Chirprate (Hz/s)','FontSize',20);
set(gca,'FontSize',20)
axis xy; 
axis([tt(1) 4 -30 50]);
% print 'example3_Nov2024_paper_sfTSCr_estimated_chirprate2_two_cosine' '-dpng' 

% [MSEIf1,MSEIf2,MSECr1,MSECr2] = MSE_ridge(CRs,IFs,der_Ph1,dder_Ph1,der_Ph2,dder_Ph2,newfreq_dis,newchr_dis); %use the portion [1/8, 7/8] of the whole time
% display(MSEIf1); display(MSECr1);
% display(MSEIf2); display(MSECr2);

% Vi=view_3D_TFC(TSCr1,tt,aa_dis,chr_dis);
% Vi1=view_3D_TFC(Tf_fm1,tt,aa_dis,chr_dis);
% Vi2=view_3D_TFC(MTSCR,tt,1./newfreq_dis, newchr_dis);
% Vi20=view_3D_TFC(MTSCR0,tt,1./newfreq_dis, newchr_dis);

%%reconstruction of components with sfTSCr (squeezed fairly decaying chirprate TSCr

recov_sfTSCr=TSCr_SSO_recov_group(tt,aa_dis,chr_dis,IFs,CRs,chirp1,chirp2,if1,if2,gs1,TSCr1);

%% recover mean square error 
[errorx1,errorx2] = MSE_recov_error(x1,x2,recov_sfTSCr); %use part of [1/8, 7/8]
%got errorx1 =0.0360, errorx2 =0.1059


% recovery error of x1 (real part)  
 figure, plot(tt, real(x1-recov_sfTSCr(1,:)), 'color', 'k');
  ylim([-1.5 1.5])
xlabel('Time (s)','FontSize',20);
set(gca,'FontSize',20)
% print 'example3_Nov2024_paper_sfTSCr_recover_real_comp1_two_cosine' '-dpng' 


  % recovery error of x2 (real part)  
   figure, plot(tt, real(x2-recov_sfTSCr(2,:)), 'color', 'k');
  ylim([-1.5 1.5])
  xlabel('Time (s)','FontSize',20);
set(gca,'FontSize',20)
% print 'example3_Nov2024_paper_sfTSCr_recover_real_comp2_two_cosine' '-dpng' 




%%%%%%%%%%% squeezing with TSCr %%%%%%%%%%%%%%%%%%%%%%
%%%%%%% [Tf_sc, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(iter_num, TSCr,Ome, Lam2, denom,del_t,del_loga,chr_range,freq_resol,chr_resol,gam);
  [MTSCR0, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(1, TSCr1,Ome1, Lam1, denom,del_t,del_loga,chr_range,1/8,del_cr,thre);

%% 3D ridge extraction
 [IFs,CRs]=Ridge3D_max(MTSCR0,2,15,15,15);
 if1 = (newfreq_dis(IFs(:,1)));
 if2 = (newfreq_dis(IFs(:,2)));
 chirp1=(newchr_dis(CRs(:,1)));
 chirp2=(newchr_dis(CRs(:,2)));
 % if1 = smooth(medfilt1(newfreq_dis(IFs(:,1)))); if2 = smooth(medfilt1(newfreq_dis(IFs(:,2))));
 % chirp1=smooth(medfilt1(newchr_dis(CRs(:,1)))); chirp2=smooth(medfilt1(newchr_dis(CRs(:,2))));

% Plot of the extracted instantaneous frequencies
figure
e_pdph2=plot(tt,if1,'r:','linewidth',2);
hold on
pdph2=plot(tt,der_Ph2,'b-','linewidth',1);
legend([e_pdph2,pdph2],'Estimated IF of x_2(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
% axis xy; 
% axis([tt(1) 4 10 65]);
% print 'example3_Nov2024_paper_sTSCr_estimated_IF2_two_cosine' '-dpng' 

figure
e_pdph1=plot(tt,if2,'r:','linewidth',2);
hold on
pdph1=plot(tt,der_Ph1,'b-','linewidth',1);
legend([e_pdph1,pdph1],'Estimated IF of x_2(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
% axis xy; 
% axis([tt(1) 4 20 75]);
% print 'example3_Nov2024_paper_sTSCr_estimated_IF1_two_cosine' '-dpng' 


figure
e_pddph1=plot(tt,chirp2,'r:','linewidth',2);
hold on
pddph1=plot(tt,dder_Ph1,'b-','linewidth',1);
legend([e_pddph1,pddph1],'Estimated chirprate of x_1(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Chirprate (Hz/s)','FontSize',20);
set(gca,'FontSize',20)
axis xy; 
axis([tt(1) 4 -30 50]);
% print 'example3_Nov2024_paper_sTSCr_estimated_chirprate1_two_cosine' '-dpng' 

figure
e_pddph2=plot(tt,chirp1,'r:','linewidth',2);
hold on
pddph2=plot(tt,dder_Ph2,'b-','linewidth',1);
legend([e_pddph2,pddph2],'Estimated chirprate of x_2(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Chirprate (Hz/s)','FontSize',20);
set(gca,'FontSize',20)
axis xy; 
axis([tt(1) 4 -30 50]);
% print 'example3_Nov2024_paper_sTSCr_estimated_chirprate2_two_cosine' '-dpng' 

%%reconstruction of components with sfTSCr (squeezed 5 times TSCr)

recov_sTSCr=TSCr_SSO_recov_group(tt,aa_dis,chr_dis,IFs,CRs,chirp1,chirp2,if1,if2,gs1,TSCr1);

%% recover mean square error 
[errorx1_s1,errorx2_s1] = MSE_recov_error(x1,x2,recov_sTSCr) %use part of [1/8, 7/8]
%got errorx1 =0.0457, errorx2 =0.1096


% recovery error of x1 (real part)  
 figure, plot(tt, real(x1-recov_sTSCr(2,:)), 'color', 'k');
  ylim([-1.5 1.5])
xlabel('Time (s)','FontSize',20);
set(gca,'FontSize',20)
% print 'example3_Nov2024_paper_sTSCr_recover_real_comp1_two_cosine' '-dpng' 


  % recovery error of x2 (real part)  
   figure, plot(tt, real(x2-recov_sTSCr(1,:)), 'color', 'k');
  ylim([-1.5 1.5])
  xlabel('Time (s)','FontSize',20);
set(gca,'FontSize',20)
% print 'example3_Nov2024_paper_sTSCr_recover_real_comp2_two_cosine' '-dpng' 


%%%%%%%%%%% (Multiple) squeezing with TSCr %%%%%%%%%%%%%%%%%%%%%%

%%%%%%% [Tf_sc, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(iter_num, TSCr,Ome, Lam2, denom,del_t,del_loga,chr_range,freq_resol,chr_resol,gam);
  [MTSCR5, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(5, TSCr1,Ome1, Lam1, denom,del_t,del_loga,chr_range,1/8,del_cr,thre);

%% 3D ridge extraction
 [IFs,CRs]=Ridge3D_max(MTSCR5,2,15,15,15);
 if1 = (newfreq_dis(IFs(:,1)));
 if2 = (newfreq_dis(IFs(:,2)));
 chirp1=(newchr_dis(CRs(:,1)));
 chirp2=(newchr_dis(CRs(:,2)));
 % if1 = smooth(medfilt1(newfreq_dis(IFs(:,1)))); if2 = smooth(medfilt1(newfreq_dis(IFs(:,2))));
 % chirp1=smooth(medfilt1(newchr_dis(CRs(:,1)))); chirp2=smooth(medfilt1(newchr_dis(CRs(:,2))));

% Plot of the extracted instantaneous frequencies
figure
e_pdph2=plot(tt,if2,'r:','linewidth',2);
hold on 
pdph2=plot(tt,der_Ph2,'b-','linewidth',1);
legend([e_pdph2,pdph2],'Estimated IF of x_2(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
% axis xy; 
% axis([tt(1) 4 10 65]);
% print 'example3_Nov2024_paper_squ_5times_TSCr_estimated_IF2_two_cosine' '-dpng' 

figure
e_pdph1=plot(tt,if1,'r:','linewidth',2);
hold on
pdph1=plot(tt,der_Ph1,'b-','linewidth',1);
legend([e_pdph1,pdph1],'Estimated IF of x_1(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
% axis xy; 
% axis([tt(1) 4 20 75]);
% print 'example3_Nov2024_paper_squ_5times_TSCr_estimated_IF1_two_cosine' '-dpng' 


figure
e_pddph1=plot(tt,chirp1,'r:','linewidth',2);
hold on
pddph1=plot(tt,dder_Ph1,'b-','linewidth',1);
legend([e_pddph1,pddph1],'Estimated chirprate of x_1(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Chirprate (Hz/s)','FontSize',20);
set(gca,'FontSize',20)
axis xy; 
axis([tt(1) 4 -30 50]);
% print 'example3_Nov2024_paper_squ_5times_TSCr_estimated_chirprate1_two_cosine' '-dpng' 

figure
e_pddph2=plot(tt,chirp2,'r:','linewidth',2);
hold on
pddph2=plot(tt,dder_Ph2,'b-','linewidth',1);
legend([e_pddph2,pddph2],'Estimated chirprate of x_2(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Chirprate (Hz/s)','FontSize',20);
set(gca,'FontSize',20)
axis xy; 
axis([tt(1) 4 -30 50]);
% print 'example3_Nov2024_paper_squ_5times_TSCr_estimated_chirprate2_two_cosine' '-dpng' 

%%reconstruction of components with sTSCr (squeezed 5 times TSCr)

recov_squ_5times_TSCr=TSCr_SSO_recov_group(tt,aa_dis,chr_dis,IFs,CRs,chirp1,chirp2,if1,if2,gs1,TSCr1);

%% recover mean square error 
[errorx1_s5,errorx2_s5] = MSE_recov_error(x1,x2,recov_squ_5times_TSCr) %use part of [1/8, 7/8]
% errorx1_s5 =0.1699, errorx2_s5 =0.1981



% recovery error of x1 (real part)  
 figure, plot(tt, real(x1-recov_squ_5times_TSCr(1,:)), 'color', 'k');
  ylim([-1.5 1.5])
xlabel('Time (s)','FontSize',20);
set(gca,'FontSize',20)
% print 'example3_Nov2024_paper_squ_5times_TSCr_recover_real_comp1_two_cosine' '-dpng' 

% recovery error of x2 (real part)  
   figure, plot(tt, real(x2-recov_squ_5times_TSCr(2,:)), 'color', 'k');
  ylim([-1.5 1.5])
  xlabel('Time (s)','FontSize',20);
set(gca,'FontSize',20)
% print 'example3_Nov2024_paper_squ_5times_TSCr_recover_real_comp2_two_cosine' '-dpng' 











%% (Multiple) squeezing 
%%%%%%% [Tf_sc, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(iter_num, TSCr,Ome, Lam2, denom,del_t,del_loga,chr_range,freq_resol,chr_resol,gam);
% [MTSCR0, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(5, TSCr1,Ome1, Lam1, denom,del_t,del_loga,chr_range,1/8,del_cr,thre);
[MTSCR, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(1, Tf_fm1,Ome1, Lam1, denom,del_t,del_loga,chr_range,1/8,del_cr,thre);
                      
%% 3D ridge extraction
 [IFs,CRs]=Ridge3D_max(MTSCR,2,15,15,15);
% [IFs,CRs]=Ridge3D_max(MTSCR0,2,15,15,15);


 % if1 = smooth(medfilt1(newfreq_dis(IFs(:,1))));
 % if2 = smooth(medfilt1(newfreq_dis(IFs(:,2))));
 % chirp1=smooth(medfilt1(newchr_dis(CRs(:,1))));
 % chirp2=smooth(medfilt1(newchr_dis(CRs(:,2))));
 if1 = (newfreq_dis(IFs(:,1)));
 if2 = (newfreq_dis(IFs(:,2)));
 chirp1=(newchr_dis(CRs(:,1)));
 chirp2=(newchr_dis(CRs(:,2)));
% Plot of the extracted instantaneous frequencies
figure
plot(tt,if1)
hold on
plot(tt,der_Ph1)
hold on

plot(tt,if2)
hold on
plot(tt,der_Ph2)
axis xy; 
xlabel('time (s)'); 
ylabel('frequency (Hz)'); 
title('3D ridge of IFs'); 

figure
plot(tt,chirp1)
hold on
plot(tt,dder_Ph1)
hold on
plot(tt,chirp2)
hold on
plot(tt,dder_Ph2)
axis xy; 
xlabel('time (s)'); 
ylabel('chirprate (Hz)'); 
title(' 3D ridge of CRs'); 

[MSEIf1,MSEIf2,MSECr1,MSECr2] = MSE_ridge(CRs,IFs,der_Ph1,dder_Ph1,der_Ph2,dder_Ph2,newfreq_dis,newchr_dis);
display(MSEIf1); display(MSECr1);
display(MSEIf2); display(MSECr2);

figure, mesh(squeeze(abs(TSCr1(105,:,:)))); %for del_loga=1/64; if del_loga=1/128, use abs(TSCR1(210,:,:))
figure, mesh(squeeze(abs(Tf_fm1(105,:,:)))); %for del_loga=1/64

%% intersection of signal,   TSCR1,Tf_fm decay of chirprate
slice2 =squeeze(abs(TSCr1(210/2,129,:)));
figure
plot(chr_dis,slice2);
axis xy; 

slice3 =squeeze(abs(Tf_fm1(210/2,129,:)));
figure
hold on
plot(chr_dis,slice3);
axis xy; 


%% intersection of signal,   MTSCR  decay of chirprate
slice1 =squeeze(abs(MTSCR(328,129,:)));
figure
plot(newchr_dis,slice1);
axis xy; 

figure, mesh(squeeze(abs(MTSCR(328,:,:))));
figure, mesh(squeeze(abs(MTSCR0(328,:,:))));
