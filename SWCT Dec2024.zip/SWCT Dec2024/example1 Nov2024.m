%%%%%%%%%%%%%%%% Example1  t^2 %%%%%%%%%%%%%%
clear all; 
chr_range=16;
tt=0:1/128:8-1/128; del_t=1/128; %J0=ceil(0.5*L/del_loga); 
Ph2=10*tt+2*tt.^2;  der_Ph2=10+4*tt;dder_Ph2=4*ones(1,1024);
x2=exp(1i*2*pi*Ph2);
Ph1=42*tt-2*tt.^2; der_Ph1=42-4*tt;dder_Ph1=-4*ones(1,1024);
x1=exp(1i*2*pi*Ph1);
signal=x1+x2;
%del_loga=1/128;
del_loga=1/64;del_cr=1/10;
mu=1;
%Jiang, Dec 9, 2024,
%by entropy searching with del_cr=1/10; del_loga=1/64;
%chr_range=16; J0=ceil(0.5*L/del_loga);  % l=2.5, 6.3,  refined with  0.01 step,l=2.5, gs1=6.32
gs1=6.32; 

thre=0.0001;
%figure
% plot(tt,der_Ph2)
% hold on
% plot(tt,der_Ph1)
% 
% figure
% plot(tt,dder_Ph2)
% hold on
% plot(tt,dder_Ph1)

 tic, 
% [Ome1, Lam1, tW, TSCr1, denom, aa_dis,chr_dis, del_loga,chr_range]=TSCr_phasefunct_3rd(signal,del_t,del_loga,del_cr,chr_range,gs1,thre); 
 [Ome1, Lam1, tW, TSCr1, denom, aa_dis,chr_dis, del_loga,chr_range]=TSCr_phasefunct_3rd_con(signal,del_t,del_loga,del_cr,chr_range,gs1,thre); 
disp("running TSCr_phasefunct_3rd")
 toc


% filter-matched WCT
% tic, [Tf_fm]=filter_CT_window(TSCR1,aa_dis,chr_dis,tt,del_loga);
% toc
 tic, Tf_fm1=filter_CT_window_rev1(TSCr1,aa_dis,chr_dis,tt,del_loga);
 toc

%% (Multiple) squeezing 
 
%%%%%%% [Tf_sc, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(iter_num, TSCr,Ome, Lam2, denom,del_t,del_loga,chr_range,freq_resol,chr_resol,gam);
%  [MTSCR0, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(1, TSCr1,Ome1, Lam1, denom,del_t,del_loga,chr_range,1/8,del_cr,thre);
[MTSCR, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(1, Tf_fm1,Ome1, Lam1, denom,del_t,del_loga,chr_range,1/8,del_cr,thre);

%% 3D ridge extraction
 [IFs,CRs]=Ridge3D_max(MTSCR,2,15,15,15);
 % [IFs,CRs]=Ridge3D_max(MTSCR0,2,15,15,15);

 if1 = (newfreq_dis(IFs(:,1)));
 if2 = (newfreq_dis(IFs(:,2)));
 chirp1=(newchr_dis(CRs(:,1)));
 chirp2=(newchr_dis(CRs(:,2)));
 % if1 = smooth(medfilt1(newfreq_dis(IFs(:,1)))); if2 = smooth(medfilt1(newfreq_dis(IFs(:,2))));
 % chirp1=smooth(medfilt1(newchr_dis(CRs(:,1)))); chirp2=smooth(medfilt1(newchr_dis(CRs(:,2))));

% Plot of the extracted instantaneous frequencies
figure
plot(tt,if1)
hold on
plot(tt,der_Ph1)
hold on

plot(tt,if2)
hold on
plot(tt,der_Ph2)
axis xy; 
xlabel('time (s)'); 
ylabel('frequency (Hz)'); 
title('3D ridge of IFs'); 

figure
plot(tt,chirp1)
hold on
plot(tt,dder_Ph1)
hold on
plot(tt,chirp2)
hold on
plot(tt,dder_Ph2)
axis xy; 
xlabel('time (s)'); 
ylabel('chirprate (Hz)'); 
title(' 3D ridge of CRs'); 

[MSEIf1,MSEIf2,MSECr1,MSECr2] = MSE_ridge(CRs,IFs,der_Ph1,dder_Ph1,der_Ph2,dder_Ph2,newfreq_dis,newchr_dis); %use the portion [1/8, 7/8] of the whole time
display(MSEIf1); display(MSECr1);
display(MSEIf2); display(MSECr2);

Vi=view_3D_TFC(TSCr1,tt,aa_dis,chr_dis);
Vi1=view_3D_TFC(Tf_fm1,tt,aa_dis,chr_dis);
Vi2=view_3D_TFC(MTSCR,tt,1./newfreq_dis, newchr_dis);
Vi20=view_3D_TFC(MTSCR0,tt,1./newfreq_dis, newchr_dis);

figure, mesh(squeeze(abs(TSCr1(147,:,:)))); %for del_loga=1/64; if del_loga=1/128, use abs(TSCR1(294,:,:))
figure, mesh(squeeze(abs(Tf_fm1(147,:,:)))); %for del_loga=1/64

 %% projection of TSCR1 onto the  plane
slice2 =squeeze(abs(TSCr1(294/2,513,:)));%for del_loga=1/64; if del_loga=1/128, use abs(TSCR1(294,513,:))
figure
plot(chr_dis,slice2);
axis xy; 

slice3 =squeeze(abs(Tf_fm1(294/2,513,:)));%for del_loga=1/64; if del_loga=1/128, use abs(TSCR1(294,513,:))
figure
plot(chr_dis,slice3);
axis xy; 

 % projection of MTSCR onto the chirprate plane
slice1 =squeeze(abs(MTSCR(208,513,:)));
figure
plot(newchr_dis,slice1);
axis xy; 

%% Recovered components 
recov_fdTSCr=TSCr_SSO_recov_group(tt,aa_dis,chr_dis,IFs,CRs,chirp1,chirp2,if1,if2,gs1,TSCr1);


%% recover mean square error 
[errorx1,errorx2] = MSE_recov_error(x1,x2,recov_fdTSCr); %use part of [1/8, 7/8]

% recovery error of x1 (real part)  
 figure, plot(tt, real(x1-recov_fdTSCr(2,:)), 'color', 'k');
  ylim([-1.5 1.5])
  xlabel('Time (s)');

  % recovery error of x2 (real part)  
   figure, plot(tt, real(x2-recov_fdTSCr(1,:)), 'color', 'k');
  ylim([-1.5 1.5])
  xlabel('Time (s)');


%% 3D_view 
view_3D(tt,TSCr1, aa_dis, chr_dis)

view_3D(tt,Tf_fm1, aa_dis, chr_dis)