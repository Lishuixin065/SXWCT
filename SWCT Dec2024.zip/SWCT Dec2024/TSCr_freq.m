% May 28, 2024
% Note you need choose c0 below for J0=ceil(c0*L/del_loga).
% c0 is a number between 0.3 and 1. Here we set c0=0.5 for computation efficience. 
% You need to set c0=1 in some cases. Please use "figure, mesh(abs(tW))" to display CWT to decide c0     
%
% function 
%          [TSCr,tW,a_discrete,chr_discrete]=TSCr_freq(f,del_t,del_loga,del_cr,chr_range,sigma);
%
% f, input signal, with length 2^{L+1} (if not, make f have a length of 2^{L+1} by zero padding
% del_t,  time sample rate (if the user does not know del_t, then set del_t=1) 
% freq, freq-domain, FFT is used
% del_a=1/32, 1/50, 1/64 or any fraction; the discretized a are aj=2^(j*del_a)*del_t
% in Wu's paper, nv (nv=32 or nv=64) a number for discretize a, aj=2^(j/nv)*del_t 
% del_cr, chirprate sample rate for TSCr
% chr_range, chrirp rate in the range of [-chr_range, chr_range]
% sigma, sigma in the Gaussian window 
% outputs
% TSCr: time-scale-chirprate transform, ceil(L/del_a) by 2^{L+1} by (1+20/del_cr) matrix, T_f(a_j,t_m, ch_n);
% tW:  CWT, ceil(L/del_a) by 2^{L+1} matrix, W_f(a_j,t_m)
% a_discrete,chr_discrete: samples for scale a and chirprate 
% We just set mu=1


%function [tW,a_discrete0]=CWT_Morlet_freq_sigmma(f,del_t,gs);

function [TSCr,tW,a_discrete0,chr]=TSCr_freq(f,del_t,del_loga,del_cr,chr_range,gs);

chr=-chr_range:del_cr:chr_range;

mu=1; 

del_a=2^(del_loga); 

[M,N]=size(f); 

if M>N %make f is a row vector
    f=f'; 
    N=M; 
end

L=ceil(log(N)/log(2))-1; 
 
%f=[f, zeros(1,2^(L+1)-N)]; 

%f=my_hilbert(real(f)); 

N0=N;
%N=2^(L+1); 

%J_1=ceil(log(mu)/log(2)/del_loga); J0=ceil((L+log(mu)/log(2))/del_loga); 
%J_1=ceil(log(1/gs)/log(2)/del_loga);
%J0=ceil((L+log(1/gs)/log(2))/del_loga);
%   J0=ceil(L/del_loga);                            
c0=0.5; J0=ceil(c0*L/del_loga); 

%a_discrete=del_a.^((J_1:J0)); %note that a_discrete is not multiplied here by del_t. So drop del_t in other places
a_discrete=del_a.^((1:J0));
a_discrete0=a_discrete*del_t;
 fftf=fft(f); 
%tW0=zeros(J0-J_1+1, N);
tW0=zeros(J0, N);tW=zeros(J0, N0);
      for j=1:J0
        %before May 2016, hat_Psi_j=wavelet_FT_Morlet(a_discrete(j)*[0:1/N:1-1/N]);
       hat_Psi_j=wavelet_FT_Morlet_sigmma(a_discrete(j)*[0:1/N:1/2],gs);    
       tW0(j,:)=ifft([fftf(1:N/2+1).*hat_Psi_j,zeros(1,N/2-1)]); 
   end 
tW(:,1:N0)=tW0(:,1:N0);

N3=length(chr);
TSCr=zeros(J0,N0,N3); TSCr0=zeros(J0,N,N3); 

freq0=[0:1/N:1/2,-1/N:-1/N:-1/2+1/N];
for j=1:J0; 
     for n=1:N3
     % Gaussian_CTjn=Gaussian_CT(mu-a_discrete(j)*[0:1/N:1/2],chr(n)*a_discrete0(j)^2,gs);
     % TSCr0(j,:,n)=ifft([fftf(1:N/2+1).*Gaussian_CTjn,zeros(1,N/2-1)]);
      Gaussian_CTjn=Gaussian_CT(mu-a_discrete(j)*freq0,chr(n)*a_discrete0(j)^2,gs);
      TSCr0(j,:,n)=ifft(fftf.*Gaussian_CTjn);
   end 
end 
   TSCr(:,1:N0,:)=TSCr0(:,1:N0,:); 
size(TSCr0), %size(TSCr) 
