% June 18, 2016, useless
% function h=wavelet_FT_Morlet_sigmma(xi,sigmma)
% FT  this is Fourier Transform of Morlet wavelet 



function h=wavelet_FT_Morlet_sigmma(xi,gs);

mu=1;


%  h=exp(-gs^2*2*pi^2*(xi-mu).^2); with mu=1/gs; 


leng=length(xi); 

for j=1:leng
if (xi(j)>=0)
h(j)=exp(-2*pi^2*gs^2*(1-xi(j))^2);
%derivative:h(j)=xi(j)*exp(-2*pi^2*gs^2*(1-xi(j))^2);

else
    h(j)=0; 
  end
end
  
%h=exp(-2*pi^2*(1-xi).^2);
