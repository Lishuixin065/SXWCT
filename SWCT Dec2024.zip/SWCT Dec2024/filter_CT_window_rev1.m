% Dec 8, 2024, rev1, revised by Jiang 
% filter_CT_window_rev1, a modified version of filter_CT_window

function   Tf_fm=filter_CT_window_rev1(TSCr,aa_dis,chr_dis,tt,del_loga);

del_t = tt(2) - tt(1);
[N1, N2, N3] = size(TSCr); 

nu0 = del_loga; 
TSCr_abs=abs(TSCr);
%  TSCr_abs=TSCr;

L0=floor(1/del_t);
time_w=-tt(L0):del_t:tt(L0);
twlen=length(time_w); %2L0-1

sigma=0.25;

g = exp(-time_w.^2./(2*sigma^2))./(sigma*sqrt(2*pi));

%%%%%%% Note: extension is not used here 
% extension of TSCr
% TSCr_e=zeros(N1,N2+2*L0-1,N3); 
% 
% for ee=1:L0-1;
%   TSCr_e(:,ee,:)=TSCr_abs(:,L0-ee,:)*0;
% end 
% 
% for ee=L0:L0+N2-1;
%   TSCr_e(:,ee,:)=TSCr_abs(:,ee-L0+1,:);
% end 
% 
% for ee=N2+L0:2*L0+N2-1;
%   TSCr_e(:,ee,:)=TSCr_abs(:,2*N2+L0-ee,:)*0;
% end 

Tf_fm = zeros(N1, N2, N3); 
for i=1:N1
    for k=1:N3       
             for j=1:twlen         
              s=aa_dis(i)/(1+aa_dis(i)*chr_dis(k)*time_w(j));  
               if s>0
                  pp = round(log(s /del_t) / (log(2) * nu0));
               end
                   if (pp>=1 && pp<=N1)
                     for n=1:N2
                          if (j+n>=L0+1 && j+n<=L0+N2)
                           %Tf_fm(i, n, k) = Tf_fm(i, n, k) +g(j)*TSCr_e(pp, n+j, k);
                           Tf_fm(i, n, k) = Tf_fm(i, n, k) +g(j)*TSCr_abs(pp, n+j-L0, k);
                          end
                     end
                   end
            end
    end
end

Tf_fm=Tf_fm*del_t; 



