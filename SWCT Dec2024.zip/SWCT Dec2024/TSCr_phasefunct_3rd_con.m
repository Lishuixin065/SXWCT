% Nov, 2024, from TSCR_three_g0_test1
%%  Note you need choose c0 below for J0=ceil(c0*L/del_loga).
% c0 is a number between 0.3 and 1. Here we set c0=0.5 for computation efficience. 
% You need to set c0=1 in some cases. Please use "figure, mesh(abs(tW))" to display CWT to decide c0     
%
%         function [Omg, Lam, tW, TSCr, demon, a_discrete,chr_dis,del_loga,chr_range]=TSCr_phasefunct_3rdIF_2ndchr_con(f,del_t,del_loga,del_cr,chr_range,sigma, gam); 
% 3rd： 3rd order for IF, chirp rate, conventional method to derive Omg, Lam  
%
%
% f, input signal, with length 2^{L+1} (if not, make f have a length of 2^{L+1} by zero padding
% del_t,  time sample rate (if the user does not know del_t, then set del_t=1) 
% del_loga, =1/64 or 1/128
% del_cr, chirprate sample rate for TSCr
% chr_range, chrirp rate in the range of [-chr_range, chr_range]
% sigma, sigma in the Gaussian window 
% gam  threshold (10^(-4) for noiseless case)
% 
% outputs
% Omg: Omega --- IF estimate  
% Lam: Lambda ---- chirprate estimate
% TSCr: (denoted by C0 below) time-scale-chirprate transform, T_f(a_j,t_m, ch_n)
% 
% tW:  CWT, ceil(L/del_a) by 2^{L+1} matrix, W_f(a_j,t_m)

function [Ome, Lam, tW, TSCr, denom, a_discrete0,chr,del_loga,chr_range]=TSCr_phasefunct_3rd_con(f,del_t,del_loga,del_cr,chr_range,gs1,gam);
%We consider the chirprate in [-chr_range, chr_range];  
chr=-chr_range:del_cr:chr_range;

mu=1; 

%del_loga=1/128; % you may set del_a=1/128, 1/64, ...

del_a=2^(del_loga); 

[M,N]=size(f); 

if M>N %make f is a row vector
    f=f'; 
    N=M; 
end

 L=ceil(log(N)/log(2))-1; 
 
%f=[f, zeros(1,2^(L+1)-N)]; 

%f=my_hilbert(real(f)); 

N0=N;
%N=2^(L+1); 

%J_1=ceil(log(mu)/log(2)/del_loga); J0=ceil((L+log(mu)/log(2))/del_loga); 
%J_1=ceil(log(1/gs)/log(2)/del_loga);
%J0=ceil((L+log(1/gs)/log(2))/del_loga);
         
%   J0=ceil(L/del_loga);                            
c0=0.5; J0=ceil((c0*L)/del_loga);

%a_discrete=del_a.^((J_1:J0)); %note that a_discrete is not multiplied here by del_t. So drop del_t in other places
%a_discrete=del_a.^((1:J0));
a_discrete=del_a.^((1:J0));
a_discrete0=a_discrete*del_t; 
 fftf=fft(f); 
tW0=zeros(J0, N);tW=zeros(J0, N0);

for j=1:J0
       hat_Psi_j=wavelet_FT_Morlet_sigmma(a_discrete(j)*([0:1/N:1/2]),gs1);    
       tW0(j,:)=ifft([fftf(1:N/2+1).*hat_Psi_j,zeros(1,N/2-1)]); 
   end 
tW(:,1:N0)=tW0(:,1:N0);

N3=length(chr);

TSCr=zeros(J0,N0,N3); TSCr_t=zeros(J0,N0,N3); TSCr_tt=zeros(J0,N0,N3); 
TSCr_ttt=zeros(J0,N0,N3);  TSCr_tttt=zeros(J0,N0,N3); 

freq0=[0:1/N:1/2,-1/N:-1/N:-1/2+1/N];

local_chr=chr;
for j=1:J0 
    for n=1:N3
[CTgjn, CT_tgjn, CT_ttgjn, CT_tttgjn, CT_ttttgjn]=Gaussian_ttttg_CT(mu-a_discrete(j)*freq0,local_chr(n)*a_discrete0(j)^2,gs1);
      TSCr(j,:,n)=ifft(fftf.*CTgjn);
      TSCr_t(j,:,n)=ifft(fftf.*CT_tgjn);
      TSCr_tt(j,:,n)=ifft(fftf.*CT_ttgjn);
      TSCr_ttt(j,:,n)=ifft(fftf.*CT_tttgjn);
      TSCr_tttt(j,:,n)=ifft(fftf.*CT_ttttgjn);
   end 
end 
size(TSCr_ttt)

denom=(TSCr_ttt.*TSCr-TSCr_tt.*TSCr_t).^2+(TSCr_tt.*TSCr_tt-TSCr.*TSCr_tttt).*(TSCr_tt.*TSCr-TSCr_t.*TSCr_t);
numer1=2*TSCr_t.*TSCr.*(TSCr_ttt.*TSCr-TSCr_tt.*TSCr_t)+TSCr.^2.*(TSCr_tt.*TSCr_tt-TSCr.*TSCr_tttt);
numer2=2*TSCr_t.*TSCr.*(TSCr_tt.*TSCr-TSCr_t.*TSCr_t)+TSCr.^2.*(TSCr_tt.*TSCr_t-TSCr.*TSCr_ttt);
 
A=zeros(J0,N0,N3);   
 one0=ones(N0,N3);one1=ones(J0,N0);
 lam0=zeros(J0,N0,N3);
 parfor j=1:J0
     A(j,:,:)=a_discrete0(j)*one0;    
 end 

 parfor n=1:N3
     lam0(:,:,n)=chr(n)*one1; 
 end 

A1=1./(2*pi*1i*A.^2); A2=1./(1i*pi*A.^3);

denom=(TSCr_ttt.*TSCr-TSCr_tt.*TSCr_t).^2+(TSCr_tt.*TSCr_tt-TSCr.*TSCr_tttt).*(TSCr_tt.*TSCr-TSCr_t.*TSCr_t);
numer1=2*TSCr_t.*TSCr.*(TSCr_ttt.*TSCr-TSCr_tt.*TSCr_t)+TSCr.^2.*(TSCr_tt.*TSCr_tt-TSCr.*TSCr_tttt);
numer2=2*TSCr_t.*TSCr.*(TSCr_tt.*TSCr-TSCr_t.*TSCr_t)+TSCr.^2.*(TSCr_tt.*TSCr_t-TSCr.*TSCr_ttt);
clear TSCr_ttt TSCr_tttt;

D2=lam0+A1./gs1^2-A1.*(numer1./denom); 
D3=(A2.*numer2./denom);
clear A1 A2 numer1 numer2;

D1=1./A+(1./(1i*2*pi*gs1^2)./A).*TSCr_t./TSCr+A.*(lam0-D2).*TSCr_t./TSCr-A.^2.*D3.*TSCr_tt./TSCr./2;

clear A  TSCr_t TSCr_tt lam0;

Ome=real(D1);
Lam=real(D2);

clear D3 D2 D1 ;
 
freq_bound=1/2/del_t; 
ind0=(abs(TSCr)<gam); 
ind1=(abs(denom)<gam);
ind2=(Ome>freq_bound)|(Ome <= gam); 
mch=max(abs(chr)); ind3=(abs(Lam)>mch); 

Ome(ind0)=0; Ome(ind1)=0;Ome(ind2)=0;
Lam(ind0)=0; Lam(ind1)=0;Lam(ind3)=0;

clear ind1 ind2 ind3 ind0
