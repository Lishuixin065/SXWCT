
%%%%%%%%%%%%%%%% Example 1  two linear chirps  %%%%%%%%%%%%%%
clear all; 
chr_range=16;
tt=0:1/128:8-1/128; del_t=1/128; %J0=ceil(0.5*L/del_loga); 
Ph2=10*tt+2*tt.^2;  der_Ph2=10+4*tt;dder_Ph2=4*ones(1,1024);
x2=exp(1i*2*pi*Ph2);
Ph1=42*tt-2*tt.^2; der_Ph1=42-4*tt;dder_Ph1=-4*ones(1,1024);
x1=exp(1i*2*pi*Ph1);
signal=x1+x2;
%del_loga=1/128;
del_loga=1/64;del_cr=1/10;
mu=1;


figure
pdph1=plot(tt,der_Ph1,'r-','linewidth',2);
hold on
pdph2=plot(tt,der_Ph2,'b-','linewidth',2);
legend([pdph1,pdph2],'\phi_1^{\prime}(t)','\phi_2^{\prime}(t)');
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
set(gca, 'YTick',[10 26 42], 'YTickLabel', {'10','26', '42'})
axis xy; 
axis([tt(1) 8 5 50]);
% print 'example1_Nov2024_paper_IFs_two_linerchirps' '-dpng' 

%Jiang, Dec 9, 2024,
%by entropy searching with del_cr=1/10; del_loga=1/64;
%chr_range=16; J0=ceil(0.5*L/del_loga);  % l=2.5, 6.3,  refined with  0.01 step,l=2.5, gs1=6.32
gs1=6.32; 

thre=0.0001;
%calculate TSCRr (WCT)
[TSCr1,tW,aa_dis,chr_dis]=TSCr_freq(signal,del_t,del_loga,del_cr,chr_range,gs1);

% calculate X-ray WCT (also called filter-matched WCT, fairly-dcaying-chirprate WCT)
% tic, [Tf_fm]=filter_CT_window(TSCR1,aa_dis,chr_dis,tt,del_loga);
% toc
 tic, Tf_fm1=filter_CT_window_rev1(TSCr1,aa_dis,chr_dis,tt,del_loga);
 toc

 %colormap(hsv);
figure, mesh(chr_dis,tt,squeeze(abs(TSCr1(147,:,:)))); %for del_loga=1/64; if del_loga=1/128, use abs(TSCR1(294,:,:))
ylabel('Time (s)', 'Rotation', -21,'FontSize',20)
xlabel('Chirprate (Hz/s)', 'Rotation', 18,'FontSize',20)
%zlabel('force[N]')
set(gca, 'YTick',[0 2 4 6 8], 'YTickLabel', {'0','2','4','6', '8'})
set(gca, 'XTick',[-20 -10 0 10 20], 'XTickLabel', {'-20','-10','0','10','20'})
set(gca,'FontSize',20)
% print 'example1_Nov2024_paper_TSCr_a147_two_linearchirps' '-dpng' 

figure, mesh(chr_dis,tt,squeeze(abs(Tf_fm1(147,:,:)))); %for del_loga=1/64; if del_loga=1/128, use abs(TSCR1(294,:,:))
ylabel('Time (s)', 'Rotation', -21,'FontSize',20)
xlabel('Chirprate (Hz/s)', 'Rotation', 18,'FontSize',20)
%zlabel('force[N]')
set(gca, 'YTick',[0 2 4 6 8], 'YTickLabel', {'0','2','4','6', '8'})
set(gca, 'XTick',[-20 -10 0 10 20], 'XTickLabel', {'-20','-10','0','10','20'})
set(gca,'FontSize',20)
% print 'example1_Nov2024_paper_faird_TSCr_a147_two_linearchirps' '-dpng' 

 %% projection of TSCR1 onto the  plane
slice2 =squeeze(abs(TSCr1(294/2,513,:)));%for del_loga=1/64; if del_loga=1/128, use abs(TSCR1(294,513,:))
figure
plot(chr_dis,slice2,'linewidth',2)
xlabel('Chirprate (Hz/s)', 'FontSize',20);
axis xy; 
set(gca,'FontSize',20)
% print 'example1_Nov2024_paper_TSCr_a147_t513_two_linearchirps' '-dpng' 


slice3 =squeeze(abs(Tf_fm1(294/2,513,:)));%for del_loga=1/64; if del_loga=1/128, use abs(TSCR1(294,513,:))
figure
plot(chr_dis,slice3,'linewidth',2)
xlabel('Chirprate (Hz/s)', 'FontSize',20);
axis xy; 
set(gca,'FontSize',20)
% print 'example1_Nov2024_paper_faird_TSCr_a147_t513_two_linearchirps' '-dpng' 

 % projection of MTSCR onto the chirprate plane
% slice1 =squeeze(abs(MTSCR0(208,513,:)));
% figure
% plot(newchr_dis,slice1);
% axis xy; 
% 

%%%%%%%%%%%%%%% 3D view of TSCr and fair decaying chirprate TSCr  %%%

%% 3D_view 
view_3D(tt,TSCr1, aa_dis, chr_dis)

view_3D(tt,Tf_fm1, aa_dis, chr_dis)


%%%%%%%%%%% squeezing with Tf_fm1, fair decaying chirprate TSCr%%%%%%%%%%%%%%%%%%%%%%

tic, 
% [Ome1, Lam1, tW, TSCr1, denom, aa_dis,chr_dis, del_loga,chr_range]=TSCr_phasefunct_3rd(signal,del_t,del_loga,del_cr,chr_range,gs1,thre); 
 [Ome1, Lam1, tW, TSCr1, denom, aa_dis,chr_dis, del_loga,chr_range]=TSCr_phasefunct_3rd_con(signal,del_t,del_loga,del_cr,chr_range,gs1,thre); 
disp("running TSCr_phasefunct_3rd")
 toc

%%%%%%% [Tf_sc, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(iter_num, TSCr,Ome, Lam2, denom,del_t,del_loga,chr_range,freq_resol,chr_resol,gam);
[MTSCR, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(1, Tf_fm1,Ome1, Lam1, denom,del_t,del_loga,chr_range,1/8,del_cr,thre);

%% 3D ridge extraction
 [IFs,CRs]=Ridge3D_max(MTSCR,2,15,15,15);

 if1 = (newfreq_dis(IFs(:,1))); %actually this is estimated IF of x2
 if2 = (newfreq_dis(IFs(:,2)));
 chirp1=(newchr_dis(CRs(:,1))); %actually this is estimated chrirprate of x2
 chirp2=(newchr_dis(CRs(:,2)));
 % if1 = smooth(medfilt1(newfreq_dis(IFs(:,1)))); if2 = smooth(medfilt1(newfreq_dis(IFs(:,2))));
 % chirp1=smooth(medfilt1(newchr_dis(CRs(:,1)))); chirp2=smooth(medfilt1(newchr_dis(CRs(:,2))));

% Plot of the extracted instantaneous frequencies
figure
pdph2=plot(tt,der_Ph2,'b-','linewidth',1)
hold on
e_pdph2=plot(tt,if1,'r:','linewidth',2)
legend([e_pdph2,pdph2],'Estimated IF of x_2(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
set(gca, 'YTick',[10 26 42], 'YTickLabel', {'10','26', '42'})
axis xy; 
axis([tt(1) 8 5 60]);
% print 'example1_Nov2024_paper_sfTSCr_estimated_IF2_two_linearchirps' '-dpng' 

figure
e_pdph1=plot(tt,if2,'r:','linewidth',2)
hold on
pdph1=plot(tt,der_Ph1,'b-','linewidth',1)
legend([e_pdph1,pdph1],'Estimated IF of x_1(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
set(gca, 'YTick',[10 26 42], 'YTickLabel', {'10','26', '42'})
axis xy; 
axis([tt(1) 8 5 60]);
% print 'example1_Nov2024_paper_sfTSCr_estimated_IF1_two_linearchirps' '-dpng' 


figure
e_pddph1=plot(tt,chirp2,'r:','linewidth',2)
hold on
pddph1=plot(tt,dder_Ph1,'b-','linewidth',1)
legend([e_pddph1,pddph1],'Estimated chirprate of x_1(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Chirprate (Hz/s)','FontSize',20);
set(gca,'FontSize',20)
%set(gca, 'YTick',[10 26 42], 'YTickLabel', {'10','26', '42'})
%axis xy; 
%axis([tt(1) 8 -4.5 0]);
% print 'example1_Nov2024_paper_sfTSCr_estimated_chirprate1_two_linearchirps' '-dpng' 

figure
e_pddph2=plot(tt,chirp1,'r:','linewidth',2)
hold on
pddph2=plot(tt,dder_Ph2,'b-','linewidth',1)
legend([e_pddph2,pddph2],'Estimated chirprate of x_2(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Chirprate (Hz/s)','FontSize',20);
set(gca,'FontSize',20)
%set(gca, 'YTick',[10 26 42], 'YTickLabel', {'10','26', '42'})
%axis xy; 
%axis([tt(1) 8 -4.5 0]);
% print 'example1_Nov2024_paper_sfTSCr_estimated_chirprate2_two_linearchirps' '-dpng' 

% [MSEIf1,MSEIf2,MSECr1,MSECr2] = MSE_ridge(CRs,IFs,der_Ph1,dder_Ph1,der_Ph2,dder_Ph2,newfreq_dis,newchr_dis); %use the portion [1/8, 7/8] of the whole time
% display(MSEIf1); display(MSECr1);
% display(MSEIf2); display(MSECr2);

% Vi=view_3D_TFC(TSCr1,tt,aa_dis,chr_dis);
% Vi1=view_3D_TFC(Tf_fm1,tt,aa_dis,chr_dis);
% Vi2=view_3D_TFC(MTSCR,tt,1./newfreq_dis, newchr_dis);
% Vi20=view_3D_TFC(MTSCR0,tt,1./newfreq_dis, newchr_dis);

%%reconstruction of components with sfTSCr (squeezed fairly decaying chirprate TSCr

recov_sfTSCr=TSCr_SSO_recov_group(tt,aa_dis,chr_dis,IFs,CRs,chirp1,chirp2,if1,if2,gs1,TSCr1);

%% recover mean square error 
[errorx1,errorx2] = MSE_recov_error(x1,x2,recov_sfTSCr); %use part of [1/8, 7/8]
%got errorx1 =0.0237, errorx2 =0.0232


% recovery error of x1 (real part)  
 figure, plot(tt, real(x1-recov_sfTSCr(2,:)), 'color', 'k');
  ylim([-1.5 1.5])
xlabel('Time (s)','FontSize',20);
set(gca,'FontSize',20)
% print 'example1_Nov2024_paper_sfTSCr_recover_real_comp1_two_linearchirps' '-dpng' 


  % recovery error of x2 (real part)  
   figure, plot(tt, real(x2-recov_sfTSCr(1,:)), 'color', 'k');
  ylim([-1.5 1.5])
  xlabel('Time (s)','FontSize',20);
set(gca,'FontSize',20)
% print 'example1_Nov2024_paper_sfTSCr_recover_real_comp2_two_linearchirps' '-dpng' 



%%%%%%%%%%% squeezing with TSCr %%%%%%%%%%%%%%%%%%%%%%
%%%%%%% [Tf_sc, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(iter_num, TSCr,Ome, Lam2, denom,del_t,del_loga,chr_range,freq_resol,chr_resol,gam);
  [MTSCR0, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(1, TSCr1,Ome1, Lam1, denom,del_t,del_loga,chr_range,1/8,del_cr,thre);

%% 3D ridge extraction
 [IFs,CRs]=Ridge3D_max(MTSCR0,2,15,15,15);
 if1 = (newfreq_dis(IFs(:,1)));
 if2 = (newfreq_dis(IFs(:,2)));
 chirp1=(newchr_dis(CRs(:,1)));
 chirp2=(newchr_dis(CRs(:,2)));
 % if1 = smooth(medfilt1(newfreq_dis(IFs(:,1)))); if2 = smooth(medfilt1(newfreq_dis(IFs(:,2))));
 % chirp1=smooth(medfilt1(newchr_dis(CRs(:,1)))); chirp2=smooth(medfilt1(newchr_dis(CRs(:,2))));

% Plot of the extracted instantaneous frequencies
figure
pdph2=plot(tt,der_Ph2,'b-','linewidth',1)
hold on
e_pdph2=plot(tt,if2,'r:','linewidth',2)
legend([e_pdph2,pdph2],'Estimated IF of x_2(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
set(gca, 'YTick',[10 26 42], 'YTickLabel', {'10','26', '42'})
axis xy; 
axis([tt(1) 8 5 60]);
% print 'example1_Nov2024_paper_sTSCr_estimated_IF2_two_linearchirps' '-dpng' 

figure
e_pdph1=plot(tt,if1,'r:','linewidth',2)
hold on
pdph1=plot(tt,der_Ph1,'b-','linewidth',1)
legend([e_pdph1,pdph1],'Estimated IF of x_2(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
set(gca, 'YTick',[10 26 42], 'YTickLabel', {'10','26', '42'})
axis xy; 
axis([tt(1) 8 5 60]);
% print 'example1_Nov2024_paper_sTSCr_estimated_IF1_two_linearchirps' '-dpng' 


figure
e_pddph1=plot(tt,chirp1,'r:','linewidth',2)
hold on
pddph1=plot(tt,dder_Ph1,'b-','linewidth',1)
legend([e_pddph1,pddph1],'Estimated chirprate of x_1(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Chirprate (Hz/s)','FontSize',20);
set(gca,'FontSize',20)
%set(gca, 'YTick',[10 26 42], 'YTickLabel', {'10','26', '42'})
%axis xy; 
axis([tt(1) 8 -5 1]);
% print 'example1_Nov2024_paper_sTSCr_estimated_chirprate1_two_linearchirps' '-dpng' 

figure
e_pddph2=plot(tt,chirp2,'r:','linewidth',2)
hold on
pddph2=plot(tt,dder_Ph2,'b-','linewidth',1)
legend([e_pddph2,pddph2],'Estimated chirprate of x_2(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Chirprate (Hz/s)','FontSize',20);
set(gca,'FontSize',20)
%set(gca, 'YTick',[10 26 42], 'YTickLabel', {'10','26', '42'})
%axis xy; 
axis([tt(1) 8 -1 5]);
% print 'example1_Nov2024_paper_sTSCr_estimated_chirprate2_two_linearchirps' '-dpng' 

%%%%%%%%%%% (Multiple) squeezing with TSCr %%%%%%%%%%%%%%%%%%%%%%

%%%%%%% [Tf_sc, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(iter_num, TSCr,Ome, Lam2, denom,del_t,del_loga,chr_range,freq_resol,chr_resol,gam);
  [MTSCR5, newfreq_dis, newchr_dis]=Stscr_freq_MOmeLam(5, TSCr1,Ome1, Lam1, denom,del_t,del_loga,chr_range,1/8,del_cr,thre);

%% 3D ridge extraction
 [IFs,CRs]=Ridge3D_max(MTSCR5,2,15,15,15);
 if1 = (newfreq_dis(IFs(:,1)));
 if2 = (newfreq_dis(IFs(:,2)));
 chirp1=(newchr_dis(CRs(:,1)));
 chirp2=(newchr_dis(CRs(:,2)));
 % if1 = smooth(medfilt1(newfreq_dis(IFs(:,1)))); if2 = smooth(medfilt1(newfreq_dis(IFs(:,2))));
 % chirp1=smooth(medfilt1(newchr_dis(CRs(:,1)))); chirp2=smooth(medfilt1(newchr_dis(CRs(:,2))));

% Plot of the extracted instantaneous frequencies
figure
pdph2=plot(tt,der_Ph2,'b-','linewidth',1)
hold on
e_pdph2=plot(tt,if1,'r:','linewidth',2)
legend([e_pdph2,pdph2],'Estimated IF of x_2(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
set(gca, 'YTick',[10 26 42], 'YTickLabel', {'10','26', '42'})
axis xy; 
axis([tt(1) 8 5 60]);
% print 'example1_Nov2024_paper_squ_5times_TSCr_estimated_IF2_two_linearchirps' '-dpng' 

figure
e_pdph1=plot(tt,if2,'r:','linewidth',2)
hold on
pdph1=plot(tt,der_Ph1,'b-','linewidth',1)
legend([e_pdph1,pdph1],'Estimated IF of x_1(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
set(gca, 'YTick',[10 26 42], 'YTickLabel', {'10','26', '42'})
axis xy; 
axis([tt(1) 8 5 60]);
% print 'example1_Nov2024_paper_squ_5times_TSCr_estimated_IF1_two_linearchirps' '-dpng' 


figure
e_pddph1=plot(tt,chirp2,'r:','linewidth',2)
hold on
pddph1=plot(tt,dder_Ph1,'b-','linewidth',1)
legend([e_pddph1,pddph1],'Estimated chirprate of x_1(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Chirprate (Hz/s)','FontSize',20);
set(gca,'FontSize',20)
%set(gca, 'YTick',[10 26 42], 'YTickLabel', {'10','26', '42'})
%axis xy; 
axis([tt(1) 8 -5 2]);
% print 'example1_Nov2024_paper_squ_5times_TSCr_estimated_chirprate1_two_linearchirps' '-dpng' 

figure
e_pddph2=plot(tt,chirp1,'r:','linewidth',2)
hold on
pddph2=plot(tt,dder_Ph2,'b-','linewidth',1)
legend([e_pddph2,pddph2],'Estimated chirprate of x_2(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Chirprate (Hz/s)','FontSize',20);
set(gca,'FontSize',20)
%set(gca, 'YTick',[10 26 42], 'YTickLabel', {'10','26', '42'})
%axis xy; 
axis([tt(1) 8 -2 5]);
% print 'example1_Nov2024_paper_squ_5times_TSCr_estimated_chirprate2_two_linearchirps' '-dpng' 


%%reconstruction of components with sTSCr (squeezed 5 times TSCr)

recov_squ_5times_TSCr=TSCr_SSO_recov_group(tt,aa_dis,chr_dis,IFs,CRs,chirp1,chirp2,if1,if2,gs1,TSCr1);

%% recover mean square error 
[errorx1_s5,errorx2_s5] = MSE_recov_error(x1,x2,recov_squ_5times_TSCr) %use part of [1/8, 7/8]
%got errorx1 =0.0526, errorx2 =0.0526


% recovery error of x1 (real part)  
 figure, plot(tt, real(x1-recov_squ_5times_TSCr(2,:)), 'color', 'k');
  ylim([-1.5 1.5])
xlabel('Time (s)','FontSize',20);
set(gca,'FontSize',20)
% print 'example1_Nov2024_paper_squ_5times_TSCr_recover_real_comp1_two_linearchirps' '-dpng' 


  % recovery error of x2 (real part)  
   figure, plot(tt, real(x2-recov_squ_5times_TSCr(1,:)), 'color', 'k');
  ylim([-1.5 1.5])
  xlabel('Time (s)','FontSize',20);
set(gca,'FontSize',20)
% print 'example1_Nov2024_paper_squ_5times_TSCr_recover_real_comp2_two_linearchirps' '-dpng' 

%%%%%%%%%%%%%%%%% use simple direct method with TSCr1 %%%%%%%%%%%
TSCr=TSCr1; 
BB=abs(TSCr);[N1,N2,N3]=size(TSCr); 

LL1=floor(N3/2);

BB1=BB(:,:,1:LL1);
BB3=BB(:,:,LL1+1:N3);

for n2=1:N2
[mc1,Ic1]=max(BB1(:,n2,:)); %find max among each column  
[MM1,II1]=max(mc1);
ind1_11(n2)=Ic1(II1);
ind3_11(n2)=II1;
Ma11(n2)=MM1;
end;

%figure, scatter3(tt, 1./aa_dis(ind1_11), chr_dis(ind3_11));

figure
e_pdph1_SSO=plot(tt, 1./aa_dis(ind1_11),'r:','linewidth',2);
hold on
pdph1=plot(tt,der_Ph1,'b-','linewidth',1)
legend([e_pdph1_SSO,pdph1],'Estimated IF of x_1(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
set(gca, 'YTick',[10 26 46], 'YTickLabel', {'10','26', '46'})
axis xy; 
axis([tt(1) 8 5 60]);
% print 'example1_Nov2024_paper_SSO_estimated_IF1_two_linearchirps' '-dpng' 


figure
e_pddph1_SSO=plot(tt,chr_dis(ind3_11),'r:','linewidth',2)
hold on
pddph1=plot(tt,dder_Ph1,'b-','linewidth',1)
legend([e_pddph1_SSO,pddph1],'Estimated chirprate of x_1(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Chirprate (Hz/s)','FontSize',20);
set(gca,'FontSize',20)
%set(gca, 'YTick',[10 26 42], 'YTickLabel', {'10','26', '42'})
%axis xy; 
axis([tt(1) 8 -5 2]);
% print 'example1_Nov2024_paper_XR_SSO_estimated_chirprate1_two_linearchirps' '-dpng' 


for n2=1:N2
[mc3,Ic3]=max(BB3(:,n2,:)); %find max among each column  
[MM3,II3]=max(mc3);
ind1_33(n2)=Ic3(II3);
ind3_33(n2)=II3;
Ma11(n2)=MM3;
end;

figure
e_pdph2_SSO=plot(tt, 1./aa_dis(ind1_33),'r:','linewidth',2);
hold on
pdph2=plot(tt,der_Ph2,'b-','linewidth',1)
legend([e_pdph2_SSO,pdph2],'Estimated IF of x_2(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
set(gca, 'YTick',[10 26 46], 'YTickLabel', {'10','26', '46'})
axis xy; 
axis([tt(1) 8 5 60]);
% print 'example1_Nov2024_paper_SSO_estimated_IF2_two_linearchirps' '-dpng' 


figure
e_pddph2_SSO=plot(tt,chr_dis(ind3_33)+LL1*del_cr,'r:','linewidth',2)
hold on
pddph2=plot(tt,dder_Ph2,'b-','linewidth',1)
legend([e_pddph2_SSO,pddph2],'Estimated chirprate of x_2(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Chirprate (Hz/s)','FontSize',20);
set(gca,'FontSize',20)
%set(gca, 'YTick',[10 26 42], 'YTickLabel', {'10','26', '42'})
%axis xy; 
axis([tt(1) 8 -2 5]);
% print 'example1_Nov2024_paper_SSO_estimated_chirprate2_two_linearchirps' '-dpng' 



%%%%%%%%%%%%%%%%% use simple direct method with X-ray TSCr1 %%%%%%%%%%%
TSCr=Tf_fm1; 
BB=abs(TSCr);[N1,N2,N3]=size(TSCr); 

LL1=floor(N3/2);

BB1=BB(:,:,1:LL1);
BB3=BB(:,:,LL1+1:N3);

for n2=1:N2
[mc1,Ic1]=max(BB1(:,n2,:)); %find max among each column  
[MM1,II1]=max(mc1);
ind1_11(n2)=Ic1(II1);
ind3_11(n2)=II1;
Ma11(n2)=MM1;
end;

%figure, scatter3(tt, 1./aa_dis(ind1_11), chr_dis(ind3_11));

figure
e_pdph1_SSO=plot(tt, 1./aa_dis(ind1_11),'r:','linewidth',2);
hold on
pdph1=plot(tt,der_Ph1,'b-','linewidth',1)
legend([e_pdph1_SSO,pdph1],'Estimated IF of x_1(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
set(gca, 'YTick',[10 26 46], 'YTickLabel', {'10','26', '46'})
axis xy; 
axis([tt(1) 8 5 60]);
% print 'example1_Nov2024_paper_XR_SSO_estimated_IF1_two_linearchirps' '-dpng' 


figure
e_pddph1_SSO=plot(tt,chr_dis(ind3_11),'r:','linewidth',2)
hold on
pddph1=plot(tt,dder_Ph1,'b-','linewidth',1)
legend([e_pddph1_SSO,pddph1],'Estimated chirprate of x_1(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Chirprate (Hz/s)','FontSize',20);
set(gca,'FontSize',20)
%set(gca, 'YTick',[10 26 42], 'YTickLabel', {'10','26', '42'})
%axis xy; 
axis([tt(1) 8 -5 2]);
% print 'example1_Nov2024_paper_XR_SSO_estimated_chirprate1_two_linearchirps' '-dpng' 



for n2=1:N2
[mc3,Ic3]=max(BB3(:,n2,:)); %find max among each column  
[MM3,II3]=max(mc3);
ind1_33(n2)=Ic3(II3);
ind3_33(n2)=II3;
Ma11(n2)=MM3;
end;

figure
e_pdph2_SSO=plot(tt, 1./aa_dis(ind1_33),'r:','linewidth',2);
hold on
pdph2=plot(tt,der_Ph2,'b-','linewidth',1)
legend([e_pdph2_SSO,pdph2],'Estimated IF of x_2(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Frequency (Hz)','FontSize',20);
set(gca,'FontSize',20)
set(gca, 'YTick',[10 26 46], 'YTickLabel', {'10','26', '46'})
axis xy; 
axis([tt(1) 8 5 60]);
% print 'example1_Nov2024_paper_XR_SSO_estimated_IF2_two_linearchirps' '-dpng' 


figure
e_pddph2_SSO=plot(tt,chr_dis(ind3_33)+LL1*del_cr,'r:','linewidth',2)
hold on
pddph2=plot(tt,dder_Ph2,'b-','linewidth',1)
legend([e_pddph2_SSO,pddph2],'Estimated chirprate of x_2(t)','Ground truth');
set(legend,'FontName','Times New Roman')
xlabel('Time (s)','FontSize',20);
ylabel('Chirprate (Hz/s)','FontSize',20);
set(gca,'FontSize',20)
%set(gca, 'YTick',[10 26 42], 'YTickLabel', {'10','26', '42'})
%axis xy; 
axis([tt(1) 8 -2 5]);
% print 'example1_Nov2024_paper_XR_SSO_estimated_chirprate2_two_linearchirps' '-dpng' 








