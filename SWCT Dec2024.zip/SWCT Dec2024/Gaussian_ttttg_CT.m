% May 27, 2024
%
%         function [CTg, CT_tg, CT_ttg, CT_tttg, CT_ttttg]=Gaussian_ttttg_CT(et,ch,gs); 
%
% chirplet transform of Gaussian func g(t)= exp(-t^2/(2*gs^2)/gs/sqrt(2*pi), and tg(t), t^2g(t), t^3g(t), t^4g(t)
% CTg=int g(tau) exp(-i2pi et tau -i pi ch tau^2) dtau 
% 
% et: eta, freq
% ch: lambda, chirprate 
% gs: sigma, the parameter of Gaussian window function 

function [CTg, CT_tg, CT_ttg, CT_tttg, CT_ttttg]=Gaussian_ttttg_CT(et,ch,gs)

L0=1+1i*2*pi*ch*gs^2;

CTg=1./sqrt(L0).*exp(-2*pi^2*gs^2*et.^2./L0);

CT_tg=-1i*2*pi*gs^2*et.*(L0).^(-3/2).*exp(-2*pi^2*gs^2*et.^2./L0);

CT_ttg=gs^2*((L0).^(-3/2)-((2*pi*gs*et).^2).*(L0).^(-5/2)).*exp(-2*pi^2*gs^2*et.^2./L0);

%CT_tttg=-2*pi*gs^4*et.*(3*(L0).^(-5/2)-((2*pi*gs*et).^2).*(L0).^(-7/2)).*exp(-2*pi^2*gs^2*et.^2./L0);
%这个原来的公式少了一个i
CT_tttg=-1i*2*pi*gs^4*et.*(3*(L0).^(-5/2)-((2*pi*gs*et).^2).*(L0).^(-7/2)).*exp(-2*pi^2*gs^2*et.^2./L0);

CT_ttttg=gs^4*(3*(L0).^(-5/2)-6*((2*pi*gs*et).^2).*(L0).^(-7/2)+((2*pi*gs*et).^4).*(L0).^(-9/2)).*exp(-2*pi^2*gs^2*et.^2./L0);




