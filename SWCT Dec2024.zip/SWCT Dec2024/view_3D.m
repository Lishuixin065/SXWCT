
function view_3D(tt,TSCR1, aa_dis, chr_dis)

t_idx = 1:length(tt);
t_show = tt(t_idx);

figure
QN = 5;
D = TSCR1(:,t_idx,:);
thresh = quantile(abs(D(:)),0.9999);
D(abs(D) < thresh * (10-QN+1)/10) = thresh * (10-QN)/10;
colors = parula(QN);
D_mod = abs(D);
D_min = min(D_mod(:));
D_max = max(D_mod(:));
D_norm = (D_mod - D_min) / (D_max - D_min);
D_norm(D_norm < 0) = 0;
D_norm(D_norm > 1) = 1;
color_indices = round(D_norm * (length(colors) - 1)) + 1;
color_indices(color_indices < 1) = 1;
color_indices(color_indices > length(colors)) = length(colors);

for jj = 1: QN
    idx = find(abs(D) <= thresh * (10-jj+1)/10 & abs(D) > thresh * (10-jj)/10);
    [I1,I2,I3] = ind2sub(size(D),idx);
    scatter3(1./aa_dis(I1) , tt(I2) , chr_dis(I3) , 10, colors(color_indices(idx), :), 'filled');
    hold on
end
shading interp;
view(-12,10);

ylabel('Time (s)', 'Rotation', -48,'FontSize',20);
xlabel('Frequency (Hz)', 'Rotation', 3,'FontSize',20);
zlabel('Chirprate (Hz/s)', 'FontSize',20);
colorbar;
set(gca, 'Box', 'on');
grid on;
%title('3D Plot of TSCR');
set(gca,'FontSize',20)

% figure
% QN = 5;
% D = Tf_fm(:,t_idx,:);
% thresh = quantile(abs(D(:)),0.9999);
% D(abs(D) < thresh * (10-QN+1)/10) = thresh * (10-QN)/10;
% colors = parula(QN);
% D_mod = abs(D);
% D_min = min(D_mod(:));
% D_max = max(D_mod(:));
% D_norm = (D_mod - D_min) / (D_max - D_min);
% D_norm(D_norm < 0) = 0;
% D_norm(D_norm > 1) = 1;
% color_indices = round(D_norm * (length(colors) - 1)) + 1;
% color_indices(color_indices < 1) = 1;
% color_indices(color_indices > length(colors)) = length(colors);
% 
% for jj = 1: QN
%     idx = find(abs(D) <= thresh * (10-jj+1)/10 & abs(D) > thresh * (10-jj)/10);
%     [I1,I2,I3] = ind2sub(size(D),idx);
%     scatter3(1./aa_dis(I1) , tt(I2) , chr_dis(I3) , 10, colors(color_indices(idx), :), 'filled');
%     hold on
% end
% shading interp;
% view(30,30);
% ylabel('time (s)');
% xlabel('frequency (Hz)');
% zlabel('chirp rate');
% colorbar;
% set(gca, 'Box', 'on');
% grid on;
% title('3D Plot of TSCR');